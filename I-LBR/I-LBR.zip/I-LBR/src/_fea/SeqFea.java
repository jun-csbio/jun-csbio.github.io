package _fea;

import java.util.Vector;

import _util._Matrix;

public class SeqFea {
	public static double[][] winPSSMFea4AA(double[][] pssm, int winsize){
		int row = pssm.length;
		int col = 20;
		
		double[][] ans = new double[row][];
		for (int i = 0; i < row; i++){
			double[][] winpssm = new double[winsize][col];
			for (int j = 0; j < winsize; j++){
				int dis = j-winsize/2;
				if ((i+dis)>=0 && (i+dis)<row){
					for (int k = 0; k < col; k++)
						winpssm[j][k] = pssm[i+dis][k];
				}else{
					for (int k = 0; k < col; k++)
						winpssm[j][k] = 0.0;
				}
			}
			
			ans[i] = _Matrix.exchangeD2ArrToArr(winpssm);
		}
		
		return ans;
	}
	
	public static double[][] winPSSFea4AA(double[][] pss, int winsize){
		int row = pss.length;
		int col = 3;
		
		double[][] ans = new double[row][];
		for (int i = 0; i < row; i++){
			double[][] winpss = new double[winsize][col];
			for (int j = 0; j < winsize; j++){
				int dis = j-winsize/2;
				if ((i+dis)>=0 && (i+dis)<row){
					for (int k = 0; k < col; k++)
						winpss[j][k] = pss[i+dis][k];
				}else{
					for (int k = 0; k < col; k++)
						winpss[j][k] = 0.0;
				}
			}
			
			ans[i] = _Matrix.exchangeD2ArrToArr(winpss);
		}
		
		return ans;
	}
	
	public static double[][] winSANNa3Fea4AA(double[][] sanna3, int winsize){
		int row = sanna3.length;
		int col = 3;
		
		double[][] ans = new double[row][];
		for (int i = 0; i < row; i++){
			double[][] winsanna3 = new double[winsize][col];
			for (int j = 0; j < winsize; j++){
				int dis = j-winsize/2;
				if ((i+dis)>=0 && (i+dis)<row){
					for (int k = 0; k < col; k++)
						winsanna3[j][k] = sanna3[i+dis][k];
				}else{
					for (int k = 0; k < col; k++)
						winsanna3[j][k] = 0.0;
				}
			}
			
			ans[i] = _Matrix.exchangeD2ArrToArr(winsanna3);
		}
		
		return ans;
	}
	
	public static double[][] winSSITE4ATPFea4AA(double[][] ssite4atp, int winsize){
		int row = ssite4atp.length;
		int col = ssite4atp[0].length;
		
		double[][] ans = new double[row][];
		for (int i = 0; i < row; i++){
			double[][] winsanna3 = new double[winsize][col];
			for (int j = 0; j < winsize; j++){
				int dis = j-winsize/2;
				if ((i+dis)>=0 && (i+dis)<row){
					for (int k = 0; k < col; k++)
						winsanna3[j][k] = ssite4atp[i+dis][k];
				}else{
					for (int k = 0; k < col; k++)
						winsanna3[j][k] = 0.0;
				}
			}
			
			ans[i] = _Matrix.exchangeD2ArrToArr(winsanna3);
		}
		
		return ans;
	}
	
	public static double[][] winTMSITE4ATPFea4AA(double[][] tmsite4atp, int winsize){
		int row = tmsite4atp.length;
		int col = tmsite4atp[0].length;
		
		double[][] ans = new double[row][];
		for (int i = 0; i < row; i++){
			double[][] winsanna3 = new double[winsize][col];
			for (int j = 0; j < winsize; j++){
				int dis = j-winsize/2;
				if ((i+dis)>=0 && (i+dis)<row){
					for (int k = 0; k < col; k++)
						winsanna3[j][k] = tmsite4atp[i+dis][k];
				}else{
					for (int k = 0; k < col; k++)
						winsanna3[j][k] = 0.0;
				}
			}
			
			ans[i] = _Matrix.exchangeD2ArrToArr(winsanna3);
		}
		
		return ans;
	}
	
	// (20 + 20*G) -Dimensional PsePSSM feature
	public static double[] PsePSSM_Feature(double[][] pssm, int G) {
		int L = pssm.length;
		int col = pssm[0].length; // 20
		double[] AAC = _Matrix.mean_value_by_colum(pssm);
		Vector<double[]> AC_Vectors = new Vector<double[]>();
		// PSSM_AAC
		AC_Vectors.addElement(AAC);

		// Modified Pse_PSSM
		for (int g = 1; g <= G; g++) {
			double[] AC_g = new double[col];
			for (int j = 0; j < col; j++) {
				double temp = 0;
				for (int i = 0; i <= L - g - 1; i++) {
					temp += (pssm[i][j] - pssm[i + g][j])
							* (pssm[i][j] - pssm[i + g][j]); // Pse_PSSM
				}
				AC_g[j] = temp / (double) (L - g);
			}
			AC_Vectors.addElement(AC_g);
		}
		
		double[][] matrix = _Matrix.exchangeVDArrToD2Arr(AC_Vectors);
		double[] feature = _Matrix.toVector_by_Row(matrix);
		return feature;
	}
	
	// (3 + 3*G) -Dimensional PsePSS feature
	public static double[] PsePSS_Feature(double[][] pss, int G) {
		int L = pss.length;
		int col = pss[0].length; // 3
		double[] AAC = _Matrix.mean_value_by_colum(pss);
		Vector<double[]> AC_Vectors = new Vector<double[]>();
		// pss_AAC
		AC_Vectors.addElement(AAC);
			// Modified Pse_pss
		for (int g = 1; g <= G; g++) {
			double[] AC_g = new double[col];
			for (int j = 0; j < col; j++) {
				double temp = 0;
				for (int i = 0; i <= L - g - 1; i++) {
					temp += (pss[i][j] - pss[i + g][j])
							* (pss[i][j] - pss[i + g][j]); // Pse_pss
				}
				AC_g[j] = temp / (double) (L - g);
			}
			AC_Vectors.addElement(AC_g);
		}
		
		double[][] matrix = _Matrix.exchangeVDArrToD2Arr(AC_Vectors);
		double[] feature = _Matrix.toVector_by_Row(matrix);
		return feature;
	}
}
