package _runner;

import java.io.BufferedReader;
import java.io.File;
import java.io.FileReader;
import java.io.InputStreamReader;
import java.util.Date;
import java.util.Vector;

import _util.ConfigUtil;
import _util.StreamGobbler;
import _util._File;
import _util._Log;

public class Blastpgp {
	// input parameters
	private String protname;
	private String protseq;
	private Integer b;
	private Integer j;
	private Double h; // set blastpgp e-value
	
	// input && output
	private String save_orig_pssm;
	private String save_psitmp_chk;
	private String save_blast_out;

	// parse output
	private int[][] origPssm;
	private double[][] standardSigmoidNormPssm;
	private Vector<String[]> MSAprofile; // 12#ASS--SCDH
										 // A+S+  SCD
										 // A--CDESCD
	private double[] corrMSAseqsWeights; // which is calculated by Henikoff Scheme <<Position-based Sequence Weights>>
	
	private Vector<String[]> CMSAprofile; 	// 12#ASS--SCDH
											// A+S+  SCD
	 										// 24#A--CDESCD
	
	private static final int MAX_MSA_TEMPL_NUM = 1000;
	
	public static void main(String[] args) {
		Blastpgp blastpgp = new Blastpgp(null, 
				"VNIKTNPFKAVSFVESAIKKALDNAGYLIAEIKYDGVRGNICVDNTANSYWLSRVSKTIPALEHLNGFDVRWKRLLNDDRCFYKDGFMLDGELMVKGVDFNTGSGLLRTKWTDTKNQEFHEELFVEPIRKKDKVPFKLHTGHLHIKLYAILPLHIVESGEDCDVMTLLMQEHVKNMLPLLQEYFPEIEWQAAESYEVYDMVELQQLYEQKRAEGHEGLIVKDPMCIYKRGKKSGWWKMKPENEADGIIQGLVWGTKGLANEGKVIGFEVLLESGRLVNATNISRALMDEFTETVKEATLSQWGFFSPYGIGDNDACTINPYDGWACQISYMEETPDGSLRHPSFVMFR",
				null, null, null, "D:/seq1_pssm.txt", "D:/seq1_psitmp.chk", "D:/seq1_blast.out");
		long s_time = new Date().getTime();
		double[] ans = blastpgp.getCorrMSAseqWeightsWithHenikoffScheme();
		for (int i = 0; i < ans.length; i++){
			System.out.print(ans[i]+"\n");
		}
		long m_time = new Date().getTime();
		double[] ans1 = blastpgp.getCorrMSAseqWeightsWithHenikoffScheme();
		for (int i = 0; i < ans1.length; i++){
			System.out.print(ans1[i]+"\n");
		}
		long e_time = new Date().getTime();
		System.out.println("runing time : " + ((m_time-s_time)/1000)+"-s"+"\n"+((e_time-m_time)/1000)+"-s");
		System.out.println("HAVE A GOOD DAY!!!");
	}
	
	public Blastpgp(String protname, String protseq, 
			Integer b, Integer j, Double h,
			String save_orig_pssm,
			String save_psitmp_chk,
			String save_blast_out){
		this.protname = protname;
		this.protseq = protseq;
		this.b = b;
		this.j = j;
		this.h= h;
		this.save_orig_pssm = save_orig_pssm;
		this.save_psitmp_chk = save_psitmp_chk;
		this.save_blast_out = save_blast_out;
		
		this.origPssm = null;
		this.standardSigmoidNormPssm = null;
		this.MSAprofile = null;
		this.CMSAprofile = null;
		
		if (!new File(save_orig_pssm).isFile() 
				|| !new File(save_psitmp_chk).isFile() 
				|| !new File(save_blast_out).isFile())
			run();
	}
	
	public String getProtname() {
		return protname;
	}

	public String getProtseq() {
		return protseq;
	}

	public String getOrigPSSMPath() {
		return save_orig_pssm;
	}

	public String getPsitmp_chkPath() {
		return save_psitmp_chk;
	}

	public String getBlast_outPath() {
		return save_blast_out;
	}

	public int[][] getOrigPssm() {
		if (null == origPssm){
			parseOrigPSSMFile();
		}
		return origPssm;
	}
	
	public static int[][] getOrigPssm(String opssmpath) {
		return parseOrigPSSMFile(opssmpath);
	}
	
	
	/***
	 * @author write by Prof. Dongjun Yu
	 */
	private void parseOrigPSSMFile() {
		Vector<int[]> originalPSSMVec = new Vector<int[]>();
					//	A  R  N  D  C  Q  E  G  H  I   L   K   M   F   P   S   T   W   Y   V
		int[] LIndex = {1, 2, 3, 4, 5, 6, 7, 8, 9, 10, 11, 12, 13, 14, 15, 16, 17, 18, 10, 20 };

		try {
			BufferedReader in = new BufferedReader(new FileReader(save_orig_pssm));
			// Discard the first 3 lines
			in.readLine();
			in.readLine();
			in.readLine();
			String line = in.readLine();

			while (line != null && line.length() > 1) {
				line = line.substring(7, line.length());
				// Typically, AAIndex.length = 20
				int[] intArray = new int[20];
				int firstIndex = 0;
				int secondIndex = 0;
				for (int i = 0; i < LIndex.length; i++) {
					while (line.charAt(firstIndex) == ' ')
						firstIndex++;

					secondIndex = firstIndex;
					while (line.charAt(secondIndex) != ' ')
						secondIndex++;

					int a = Integer.parseInt(line.substring(firstIndex, secondIndex));

					intArray[LIndex[i] - 1] = a;
					firstIndex = secondIndex;
				}
				originalPSSMVec.add(intArray);
				line = in.readLine();
			}
			
			in.close();
		} catch (Exception e) {
			e.printStackTrace();
		}
		
		this.origPssm = new int[originalPSSMVec.size()][20];
		for (int i = 0; i < originalPSSMVec.size(); i++) {
			origPssm[i] = (int[]) originalPSSMVec.elementAt(i);
		}
	}
	
	/***
	 * @author write by Prof. Dongjun Yu
	 */
	public static int[][] parseOrigPSSMFile(String opssmpath) {
		Vector<int[]> originalPSSMVec = new Vector<int[]>();
					//	A  R  N  D  C  Q  E  G  H  I   L   K   M   F   P   S   T   W   Y   V
		int[] LIndex = {1, 2, 3, 4, 5, 6, 7, 8, 9, 10, 11, 12, 13, 14, 15, 16, 17, 18, 10, 20 };

		try {
			BufferedReader in = new BufferedReader(new FileReader(opssmpath));
			// Discard the first 3 lines
			in.readLine();
			in.readLine();
			in.readLine();
			String line = in.readLine();

			while (line != null && line.length() > 1) {
				line = line.substring(7, line.length());
				// Typically, AAIndex.length = 20
				int[] intArray = new int[20];
				int firstIndex = 0;
				int secondIndex = 0;
				for (int i = 0; i < LIndex.length; i++) {
					while (line.charAt(firstIndex) == ' ')
						firstIndex++;

					secondIndex = firstIndex;
					while (line.charAt(secondIndex) != ' ')
						secondIndex++;

					int a = Integer.parseInt(line.substring(firstIndex, secondIndex));

					intArray[LIndex[i] - 1] = a;
					firstIndex = secondIndex;
				}
				originalPSSMVec.add(intArray);
				line = in.readLine();
			}
			
			in.close();
		} catch (Exception e) {
			e.printStackTrace();
		}
		
		int[][] origPssm = new int[originalPSSMVec.size()][20];
		for (int i = 0; i < originalPSSMVec.size(); i++) {
			origPssm[i] = (int[]) originalPSSMVec.elementAt(i);
		}
		
		return origPssm;
	}
	
	/**
	 * @return f(x)=1/(1+(exp(-x)))
	 */
	public double[][] getStandardSigmoidNormPssm() {
		if (null == standardSigmoidNormPssm){
			standardSigmoidNormPssm = normalizeOriginalPSSM(1.0);
		}
		return standardSigmoidNormPssm;
	}
	
	/**
	 * @return f(x)=1/(1+(exp(-x)))
	 */
	public static double[][] getStandardSigmoidNormPssm(String opssmpath, int[][] opssm) {
		if (null == opssm)
			opssm = parseOrigPSSMFile(opssmpath);
		
		return normalizeOriginalPSSM(opssm, 1.0);

	}
	
	/**
	 * @param lamta
	 * @return f(x)=1/(1+(exp(-lamta*x)))
	 */
	public static double[][] getNonStandardSigmoidNormPssm(String opssmpath, int[][] opssm, double lamta){
		if (null == opssm)
			opssm = parseOrigPSSMFile(opssmpath);
		
		return normalizeOriginalPSSM(opssm, lamta);
	}
	
	/**
	 * @param lamta
	 * @return f(x)=1/(1+(exp(-lamta*x)))
	 */
	public double[][] getNonStandardSigmoidNormPssm(double lamta){
		return normalizeOriginalPSSM(lamta);
	}
	
	// Normalize the generated PSSM
	private double[][] normalizeOriginalPSSM(double lamta) {
		if (null == origPssm){
			parseOrigPSSMFile();
		}
		
		int row = origPssm.length;
		int col = origPssm[0].length;
		double[][] ans = new double[row][col];

		for (int i = 0; i < origPssm.length; i++) {
			for (int j = 0; j < origPssm[i].length; j++) {
				ans[i][j] = 1.0 / (1 + Math.exp(-lamta * origPssm[i][j]));
			}
		}
		
		return ans;
	}

	// Normalize the generated PSSM
	private static double[][] normalizeOriginalPSSM(int[][] opssm, double lamta) {
		int row = opssm.length;
		int col = opssm[0].length;
		double[][] ans = new double[row][col];
		for (int i = 0; i < opssm.length; i++) {
			for (int j = 0; j < opssm[i].length; j++) {
				ans[i][j] = 1.0 / (1 + Math.exp(-lamta * opssm[i][j]));
			}
		}
		
		return ans;
	}
	
	/***
	 * @return all alignment sequence information in this class.
	 * 			each element info:
	 *  			startOriginalPos(index start from 0)#aligned Sequence
														 Aligned matched Sequence
					                                     Aligned Template Sequence 
	 * 			e.g.:
	 * 				0#VNIKTNPFKAVSFVE...VMFR
					  +NIKTNPFKAVSFVE...VMFR
					  MNIKTNPFKAVSFVE...VMFR
	 */
	public Vector<String[]> getMSAprofile() {
		if (null == MSAprofile){
			parseBlastOutFile4MSAandCMSA();
		}
		return MSAprofile;
	}
	
	/**
	 * @return : every template sequence weights
	 * @description : we calculate these weight using the Henikoff Scheme <<Position-based Sequence Weights>>.
	 */
	public double[] getCorrMSAseqWeightsWithHenikoffScheme() {
		if (null == corrMSAseqsWeights){
			Vector<String[]> msaPro = getMSAprofile();
			corrMSAseqsWeights = new double[msaPro.size()];
			
			for (int pos = 0; pos < protseq.length(); pos++){
				if ((pos+1) % 10 == 0){
					System.out.print(".");
				}
				if ((pos+1) % 300 == 0){
					System.out.print("*");
				}
				if ((pos+1) % 600 == 0){
					System.out.println();
				}
				
				byte[] columnAAs = new byte[msaPro.size()];
				for (int j = 0; j < msaPro.size(); j++){
					char posCh = this.getIthAAofQuerySeqMatchedAAofTemplSeq(pos, msaPro.get(j));
					columnAAs[j] = (byte)posCh;
				}
				
				for (int j = 0; j < msaPro.size(); j++){
					int r = 0; // count the amino acid type number
					int s = 0; // count the special amino acid number
					byte speAA = columnAAs[j];
					
					StringBuffer sb = new StringBuffer();
					for (int k = 0; k < msaPro.size(); k++){
						if (!sb.toString().contains(""+columnAAs[k])){
							r++;
							sb.append(""+columnAAs[k]);
						}
						if (speAA == columnAAs[k])
							s++;
					}
					
					corrMSAseqsWeights[j] += 1.0/(r * s);
				}
			}
			
//			// normalized
//			for (int j = 0; j < msaPro.size(); j++) 
//				corrMSAseqsWeights[j] /= protseq.length();
			
		}
		
		return corrMSAseqsWeights;
	}
	
	/**
	 * @return : every template sequence weights
	 * @description : we calculate these weight using the Henikoff Scheme <<Position-based Sequence Weights>>.
	 */
	public double[] getCorrMSAseqWeightsWithHenikoffSchemeV2() {
		if (null == corrMSAseqsWeights){
			Vector<String[]> msaPro = getMSAprofile();
			corrMSAseqsWeights = new double[msaPro.size()];
			
			// the row index means the i-th template sequence
			// the column index means the original amino acid index of the original query sequence,
			// the [j] content means the amino acid type in the original template sequence,
			// which is aligned to the j-th amino acid of the original query sequence.
			char[][] OPpos2OTaaMap = new char[msaPro.size()][protseq.length()];
			for (int i = 0; i < msaPro.size(); i++){
				OPpos2OTaaMap[i] = this.getOQPos2OTAAMap(i);
			}
			
			for (int pos = 0; pos < protseq.length(); pos++){
				if ((pos+1) % 10 == 0){
					System.out.print(".");
				}
				if ((pos+1) % 300 == 0){
					System.out.print("*");
				}
				if ((pos+1) % 600 == 0){
					System.out.println();
				}
				
				byte[] columnAAs = new byte[msaPro.size()];
				for (int j = 0; j < msaPro.size(); j++){
					char posCh = OPpos2OTaaMap[j][pos];
//					char posCh = this.getIthAAofQuerySeqMatchedAAofTemplSeq(pos, msaPro.get(j));
					columnAAs[j] = (byte)posCh;
				}
				
				for (int j = 0; j < msaPro.size(); j++){
					int r = 0; // count the amino acid type number
					int s = 0; // count the special amino acid number
					byte speAA = columnAAs[j];
					
					StringBuffer sb = new StringBuffer();
					for (int k = 0; k < msaPro.size(); k++){
						if (!sb.toString().contains(""+columnAAs[k])){
							r++;
							sb.append(""+columnAAs[k]);
						}
						if (speAA == columnAAs[k])
							s++;
					}
					
					corrMSAseqsWeights[j] += 1.0/(r * s);
				}
			}
			
//			// normalized
//			for (int j = 0; j < msaPro.size(); j++) 
//				corrMSAseqsWeights[j] /= protseq.length();
			
		}
		
		return corrMSAseqsWeights;
	}
	
	/***
	 * @param i : the index of the original query sequence
	 * @param alignInfo : the alignment information, which is a string array with 3 length. the format is queried, matched, template information,
	 * 					 as example:
	 * 				      e.g.:
	 * 				      0#VNIKTNPFKAVSFVE...VMFR
					        +NIKTNPFKAVSFVE...VMFR
					        MNIKTNPFKAVSFVE...VMFR
	 * @description obtain the amino acid type in the aligned template sequence, which is matched/aligned
	 * 				to the i-th amino acid of the original query sequence.
	 * @return amino acid type : ~ means the i value is out of range. 
	 * 			other character (contain 20 amino acid and gap '-') is obtained from the aligned template information.
	 */
	private char getIthAAofQuerySeqMatchedAAofTemplSeq(int i, String[] alignInfo){
		String[] lc = alignInfo[0].split("#");
		int startAlignedPos = Integer.parseInt(lc[0]);
		String queryInfo = lc[1];
		String templInfo = alignInfo[2];
		
		char ans = '~'; 
		if (i >= startAlignedPos && (i-startAlignedPos)<queryInfo.replaceAll("-", "").length()){
			int index = 0, k = startAlignedPos;
			while (k <= i){
				if ('-' != queryInfo.charAt(index)){
					if (k == i){
						break;
					}
					k++;
				}
				index++;
			}
			
			ans = templInfo.charAt(index);
		}
		
		return ans;
	}
	
	/**
	 * @param i
	 * @param alignedInfoIndex
	 * @return
	 * @description obtain the amino acid type in the 'alignedInfoIndex'-th aligned template sequence, which is matched/aligned
	 * 				to the i-th amino acid of the original query sequence.
	 */
	public char getIthAAofQuerySeqMatchedAAofJthTemplSeq(int i, int alignedInfoIndex){
		if (null == MSAprofile){
			parseBlastOutFile4MSAandCMSA();
		}
		String[] alignInfo = MSAprofile.get(alignedInfoIndex);
		return getIthAAofQuerySeqMatchedAAofTemplSeq(i, alignInfo);
	}
	
	/***
	 * @param len
	 * @return	the random selected "num" different index alignment sequence information in the save_blast_out file;
	 * @return all alignment sequence information in this class.
	 * 			each element info:
	 *  			startOriginalPos(index start from 0)#aligned Sequence
														 Aligned matched Sequence
					                                     Aligned Template Sequence 
	 * 			e.g.:
	 * 				0#VNIKTNPFKAVSFVE...VMFR
					  +NIKTNPFKAVSFVE...VMFR
					  MNIKTNPFKAVSFVE...VMFR
	 */
	public Vector<String[]> getMSAprofile(int num) {
		if (null == MSAprofile){
			parseBlastOutFile4MSAandCMSA();
		}
		
		if (num>=MSAprofile.size()){
			return MSAprofile;
		}
		
		Vector<String[]> ans = new Vector<String[]>();
		for (int i = 0; i < num && i < MSAprofile.size(); i++){
			ans.add(MSAprofile.get(i));
		}
		
		return ans;
	}
	
	// the arr index means the original amino acid index of the original query sequence,
	// the [j] content means the amino acid type in the original template sequence,
	// which is aligned to the j-th amino acid of the original query sequence.
	public char[] getOQPos2OTAAMap(String[] signleMSAprofile){
		String[] lc = signleMSAprofile[0].split("#");
		int startAlignedPos = Integer.parseInt(lc[0]);
		String queryInfo = lc[1];
		String templInfo = signleMSAprofile[2];
		
		if (templInfo.contains("#")){
			String[] lcc = templInfo.split("#");
			templInfo = lcc[1];
		}
		
		
		char[] ans = new char[protseq.length()];
		for (int i = 0; i < startAlignedPos; i++){
			ans[i] = '~';
		}
		for (int i = startAlignedPos+queryInfo.replaceAll("-", "").length(); i < protseq.length(); i++){
			ans[i] = '~';
		}
		for (int i = 0, k = startAlignedPos; i < queryInfo.length(); i++){
			if ('-' != queryInfo.charAt(i)){
				ans[k++] = templInfo.charAt(i);
			}
		}
		
		return ans;
	} 	
	
	// the arr index means the original amino acid index of the original query sequence,
		// the [j] content means the amino acid type in the original template sequence,
		// which is aligned to the j-th amino acid of the original query sequence.
	public char[] getOQPos2OTAAMap(int ith){
		if (null == MSAprofile){
			this.parseBlastOutFile4MSAandCMSA();
		}
		
		String[] signleMSAprofile = this.MSAprofile.get(ith);
		String[] lc = signleMSAprofile[0].split("#");
		int startAlignedPos = Integer.parseInt(lc[0]);
		String queryInfo = lc[1];
		String templInfo = signleMSAprofile[2];
		
		if (templInfo.contains("#")){
			String[] lcc = templInfo.split("#");
			templInfo = lcc[1];
		}
		
		
		char[] ans = new char[protseq.length()];
		for (int i = 0; i < startAlignedPos; i++){
			ans[i] = '~';
		}
		for (int i = startAlignedPos+queryInfo.replaceAll("-", "").length(); i < protseq.length(); i++){
			ans[i] = '~';
		}
		for (int i = 0, k = startAlignedPos; i < queryInfo.length(); i++){
			if ('-' != queryInfo.charAt(i)){
				ans[k++] = templInfo.charAt(i);
			}
		}
		
		return ans;
	}
	
	private void parseBlastOutFile4MSAandCMSA(){
		MSAprofile = new Vector<String[]>();
		CMSAprofile = new Vector<String[]>();
		try{
			BufferedReader br = new BufferedReader(new FileReader(save_blast_out));
			String line=br.readLine();
			while (null != line){
				if (line.startsWith(" Identities =")){
					StringBuffer _tmpMSAQueryInfoSb = new StringBuffer(); // startOriginalPos(index start from 0)#aligned Sequence
					StringBuffer _tmpMSAMatchInfoSb = new StringBuffer(); // Aligned matched Sequence
					StringBuffer _tmpMSATemplInfoSb = new StringBuffer(); // Aligned Template Sequence
					StringBuffer _tmpCMSATemplInfoSb = new StringBuffer(); // startOriginalPos(index start from 0)#Aligned Template Sequence
					
					br.readLine(); // remove a space line
					String queryLine = br.readLine();
					String matchLine = br.readLine();
					String templLine = br.readLine();
					
					String queryStartPos = "0";
					String templStartPos = "0";
					boolean isSetQueryStartPos = false;
					while (true){
						if ((null==queryLine || null==matchLine || null==templLine) ||
								(queryLine.startsWith(">") || matchLine.startsWith(">") || templLine.startsWith(">")) ||
								(queryLine.startsWith("  Database:") || matchLine.startsWith("  Database:") || templLine.startsWith("  Database:")) ||
								(queryLine.startsWith("Searching") || matchLine.startsWith("Searching") || templLine.startsWith("Searching")) ||
								(queryLine.startsWith(" Score =") || matchLine.startsWith(" Score =") || templLine.startsWith(" Score =")) ||
								(queryLine.length()==0 || matchLine.length()==0 || templLine.length()==0) ||
								(!queryLine.startsWith("Query:") || !templLine.startsWith("Sbjct:"))){
							break;
						}
					
						String[] queryLc = queryLine.split(" +");
						String[] templLc = templLine.split(" +");
						if (!isSetQueryStartPos){
							queryStartPos = ""+(Integer.parseInt(queryLc[1])-1);
							_tmpMSAQueryInfoSb.append(queryStartPos+"#");
							
							templStartPos = ""+(Integer.parseInt(templLc[1])-1);
							_tmpCMSATemplInfoSb.append(templStartPos+"#");
							isSetQueryStartPos = true;
						}
						try{
							String queryInfo = queryLc[2];
							_tmpMSAQueryInfoSb.append(queryInfo);
							_tmpCMSATemplInfoSb.append(templLc[2]);
						}catch(Exception e){
							System.out.println(queryLine+"\n"+matchLine+"\n"+templLine);
							System.exit(-1);
						}
						
						String matchInfo = matchLine.substring("           ".length());
						_tmpMSAMatchInfoSb.append(matchInfo);
						
						String templInfo = templLc[2];
						_tmpMSATemplInfoSb.append(templInfo);
						
						br.readLine(); // remove a space line
						queryLine = br.readLine();
						matchLine = br.readLine();
						templLine = br.readLine();
					}
					
					String[] oneAlignMSAInfos = new String[3];
					oneAlignMSAInfos[0] = _tmpMSAQueryInfoSb.toString();
					oneAlignMSAInfos[1] = _tmpMSAMatchInfoSb.toString();
					oneAlignMSAInfos[2] = _tmpMSATemplInfoSb.toString();
					
					String[] oneAlignCMSAInfos = new String[3];
					oneAlignCMSAInfos[0] = _tmpMSAQueryInfoSb.toString();
					oneAlignCMSAInfos[1] = _tmpMSAMatchInfoSb.toString();
					oneAlignCMSAInfos[2] = _tmpCMSATemplInfoSb.toString();
					
					
					MSAprofile.add(oneAlignMSAInfos);
					CMSAprofile.add(oneAlignCMSAInfos);
					
					if (MSAprofile.size() >= MAX_MSA_TEMPL_NUM){
						break;
					}
				}
					
				line=br.readLine();
			}
			br.close();
		}catch(Exception e){
			System.out.println("parseBlastOutFile4MSA ERROR");
			e.printStackTrace();
			_Log.dayRunLog(e.getMessage(), new Date());
		}
	}
	
	public static Vector<String[]> parseBlastOutFile4MSA(String save_blast_out){
		Vector<String[]> ans = new Vector<String[]>();
		try{
			BufferedReader br = new BufferedReader(new FileReader(save_blast_out));
			String line=br.readLine();
			while (null != line){
				if (line.startsWith(" Identities =")){
					StringBuffer _tmpMSAQueryInfoSb = new StringBuffer(); // startOriginalPos(index start from 0)#aligned Sequence
					StringBuffer _tmpMSAMatchInfoSb = new StringBuffer(); // Aligned matched Sequence
					StringBuffer _tmpMSATemplInfoSb = new StringBuffer(); // Aligned Template Sequence
					
					br.readLine(); // remove a space line
					String queryLine = br.readLine();
					String matchLine = br.readLine();
					String templLine = br.readLine();
					
					String queryStartPos = "0";
					boolean isSetQueryStartPos = false;
					while (true){
						if ((null==queryLine || null==matchLine || null==templLine) ||
								(queryLine.startsWith(">") || matchLine.startsWith(">") || templLine.startsWith(">")) ||
								(queryLine.startsWith("  Database:") || matchLine.startsWith("  Database:") || templLine.startsWith("  Database:")) ||
								(queryLine.startsWith("Searching") || matchLine.startsWith("Searching") || templLine.startsWith("Searching")) ||
								(queryLine.startsWith(" Score =") || matchLine.startsWith(" Score =") || templLine.startsWith(" Score =")) ||
								(queryLine.length()==0 || matchLine.length()==0 || templLine.length()==0) ||
								(!queryLine.startsWith("Query:") || !templLine.startsWith("Sbjct:"))){
							break;
						}
					
						String[] queryLc = queryLine.split(" +");
						if (!isSetQueryStartPos){
							queryStartPos = ""+(Integer.parseInt(queryLc[1])-1);
							_tmpMSAQueryInfoSb.append(queryStartPos+"#");
							isSetQueryStartPos = true;
						}
						try{
							String queryInfo = queryLc[2];
							_tmpMSAQueryInfoSb.append(queryInfo);
						}catch(Exception e){
							System.out.println(queryLine+"\n"+matchLine+"\n"+templLine);
							System.exit(-1);
						}
						
						String matchInfo = matchLine.substring("           ".length());
						_tmpMSAMatchInfoSb.append(matchInfo);
						
						String[] templLc = templLine.split(" +");
						String templInfo = templLc[2];
						_tmpMSATemplInfoSb.append(templInfo);
						
						br.readLine(); // remove a space line
						queryLine = br.readLine();
						matchLine = br.readLine();
						templLine = br.readLine();
					}
					
					String[] oneAlignInfos = new String[3];
					oneAlignInfos[0] = _tmpMSAQueryInfoSb.toString();
					oneAlignInfos[1] = _tmpMSAMatchInfoSb.toString();
					oneAlignInfos[2] = _tmpMSATemplInfoSb.toString();
					
					ans.add(oneAlignInfos);
				}
					
				line=br.readLine();
			}
			br.close();
		}catch(Exception e){
			System.out.println("parseBlastOutFile4MSA ERROR");
			e.printStackTrace();
			_Log.dayRunLog(e.getMessage(), new Date());
		}
		
		return ans;
	}
	
	/**
	 * @param protname
	 * @param protseq
	 * @param save_orig_pssm: please set it a right value (a save file path)
	 * @param save_psitmp_chk: if you do not want to save the PSITMP.chk, you can set it to be "null"
	 * @param save_blast_out: if you do not want to save the blast.out, you can set it to be "null"
	 * @param b : if you want set the default value, you can set it to be "null"
	 * @param j : if you want set the default value, you can set it to be "null"
	 * @param h : if you want set the default value, you can set it to be "null"
	 * @description blastpgp  -b 1000 -j 3 -h 0.001 -d $nrdb -i protein.fasta -C psitmp.chk -Q pssm.txt > blast.out
	 */
	private void run(){
		String blastpgp_exe_path = ConfigUtil.getConfig("BLASTPGP_EXE_PATH");
		String blastpgp_db_path = ConfigUtil.getConfig("BLASTPGP_DB_PATH");
		
		if (null == blastpgp_exe_path || null == blastpgp_db_path){
			System.out.println("Please check the config file items : BLASTPGP_EXE_PATH, BLASTPGP_DB_PATH");
			_Log.dayRunLog("Please check the config file items : BLASTPGP_EXE_PATH, BLASTPGP_DB_PATH", new Date());
			System.exit(-1);
		}
		
		if (null == save_orig_pssm || null == protseq){
			System.out.println("the blastpgp parameters have several errors. \nprotname = "+protname+"\nsave_orig_pssm = "+save_orig_pssm+"\nprotseq = "+protseq);
			_Log.dayRunLog("the blastpgp parameters have several errors. \nprotname = "+protname+"save_orig_pssm = "+save_orig_pssm+"\nprotseq = "+protseq, new Date());
			System.exit(-1);
		}
		
		long suffix = new Date().getTime();
		String queryFaPath = "./"+protname+"_BLASTPGP_FASTE"+suffix;
		_File.writeToFile(">"+protname+"\n"+protseq.toUpperCase()+"\n", queryFaPath, false);
		
		StringBuffer cmd =  new StringBuffer();
		cmd.append(blastpgp_exe_path+" ");
		if (null != b){
			cmd.append("-b "+b+" ");
		}
		if (null != j){
			cmd.append("-j "+j+" ");
		}
		if (null != h){ // e-value
			cmd.append("-h "+h+" ");
		}
		//blastpgp  -b 1000 -j 3 -h 0.001 -d $nrdb -i protein.fasta -C psitmp.chk -Q pssm.txt > blast.out
		cmd.append("-d "+blastpgp_db_path+" ");
		cmd.append("-i "+queryFaPath+" ");
		if (null != save_psitmp_chk){
			cmd.append("-C "+save_psitmp_chk+" ");
		}
		cmd.append("-Q "+save_orig_pssm+" ");
		System.out.println(cmd.toString());
		_Log.dayRunLog(cmd.toString(), new Date());
		
		try{
			StringBuffer blast_outSB = new StringBuffer();
			Process process;
			process = Runtime.getRuntime().exec(cmd.toString());
			StreamGobbler errorGobbler = new StreamGobbler(process.getErrorStream(), "Error");
			errorGobbler.start();
			
			InputStreamReader isr = new InputStreamReader(process.getInputStream());
			BufferedReader br = new BufferedReader(isr);
			String line = null;
			while ((line = br.readLine()) != null) {
				blast_outSB.append(line+"\n");
			}
			
			process.waitFor();
			process.destroy();
			
			// save blast.out
			if (null != save_blast_out && blast_outSB.length() > 0){
				_File.writeToFile(blast_outSB.toString(), save_blast_out, false);
			}
		}catch(Exception e){
			e.printStackTrace();
			_Log.dayRunLog("Cannot correctly run \""+cmd+"\"", new Date());
			_Log.dayRunLog(e.getMessage(), new Date());
		}
		
		new File(queryFaPath).delete();
	}
	
	/**
	 * @param protname
	 * @param protseq
	 * @param save_orig_pssm: please set it a right value (a save file path)
	 * @param save_psitmp_chk: if you donot want to save the PSITMP.chk, you can set it to be "null"
	 * @param save_blast_out: if you donot want to save the blast.out, you can set it to be "null"
	 * @param b : if you want set the default value, you can set it to be "null"
	 * @param j : if you want set the default value, you can set it to be "null"
	 * @param h : if you want set the default value, you can set it to be "null"
	 * @description blastpgp  -b 1000 -j 3 -h 0.001 -d $nrdb -i protein.fasta -C psitmp.chk -Q pssm.txt > blast.out
	 */
	public static void run(String protname, String protseq, String save_orig_pssm, String save_psitmp_chk, String save_blast_out,
			Integer b, Integer j, Double h){
		String blastpgp_exe_path = ConfigUtil.getConfig("BLASTPGP_EXE_PATH");
		String blastpgp_db_path = ConfigUtil.getConfig("BLASTPGP_DB_PATH");
		
		if (null == blastpgp_exe_path || null == blastpgp_db_path){
			System.out.println("Please check the config file items : BLASTPGP_EXE_PATH, BLASTPGP_DB_PATH");
			_Log.dayRunLog("Please check the config file items : BLASTPGP_EXE_PATH, BLASTPGP_DB_PATH", new Date());
			System.exit(-1);
		}
		
		if (null == save_orig_pssm || null == protseq){
			System.out.println("the blastpgp parameters have several errors. \nprotname = "+protname+"\nsave_orig_pssm = "+save_orig_pssm+"\nprotseq = "+protseq);
			_Log.dayRunLog("the blastpgp parameters have several errors. \nprotname = "+protname+"save_orig_pssm = "+save_orig_pssm+"\nprotseq = "+protseq, new Date());
			System.exit(-1);
		}
		
		long suffix = new Date().getTime();
		String queryFaPath = "./"+protname+"_BLASTPGP_FASTE"+suffix;
		_File.writeToFile(">"+protname+"\n"+protseq.toUpperCase()+"\n", queryFaPath, false);
		
		StringBuffer cmd =  new StringBuffer();
		cmd.append(blastpgp_exe_path+" ");
		if (null != b){
			cmd.append("-b "+b+" ");
		}
		if (null != j){
			cmd.append("-j "+j+" ");
		}
		if (null != h){ // e-value
			cmd.append("-h "+h+" ");
		}
		//blastpgp  -b 1000 -j 3 -h 0.001 -d $nrdb -i protein.fasta -C psitmp.chk -Q pssm.txt > blast.out
		cmd.append("-d "+blastpgp_db_path+" ");
		cmd.append("-i "+queryFaPath+" ");
		if (null != save_psitmp_chk){
			cmd.append("-C "+save_psitmp_chk+" ");
		}
		cmd.append("-Q "+save_orig_pssm+" ");
		System.out.println(cmd.toString());
		_Log.dayRunLog(cmd.toString(), new Date());
		
		try{
			StringBuffer blast_outSB = new StringBuffer();
			Process process;
			process = Runtime.getRuntime().exec(cmd.toString());
			StreamGobbler errorGobbler = new StreamGobbler(process.getErrorStream(), "Error");
			errorGobbler.start();
			
			InputStreamReader isr = new InputStreamReader(process.getInputStream());
			BufferedReader br = new BufferedReader(isr);
			String line = null;
			while ((line = br.readLine()) != null) {
				blast_outSB.append(line+"\n");
			}
			
			process.waitFor();
			process.destroy();
			
			// save blast.out
			if (null != save_blast_out && blast_outSB.length() > 0){
				_File.writeToFile(blast_outSB.toString(), save_blast_out, false);
			}
		}catch(Exception e){
			e.printStackTrace();
			_Log.dayRunLog("Cannot correctly run \""+cmd+"\"", new Date());
			_Log.dayRunLog(e.getMessage(), new Date());
		}
		
		new File(queryFaPath).delete();
	}

}
