package _sample;

import java.io.FileWriter;
import java.text.DecimalFormat;

public class SampleSaved {
	// the last dimension is label
	public static void saveUseLIBSVMFormatBySpace(double[][] partten_label, String filePath){
		try{
			writeToFileWithLIBSVMFormat(partten_label, filePath);
		}catch(Exception e){
			e.printStackTrace();
		}
	}
	
	// the last dimension is label
	private static void writeToFileWithLIBSVMFormat(double[][] partten_label, String filePath) throws Exception{
			DecimalFormat df = new DecimalFormat();
			df.applyPattern("#0.00000000");
			
			FileWriter fw = new FileWriter(filePath);
			int num = partten_label.length;
			int partten_dim = partten_label[0].length - 1;
			for (int i = 0; i < num; i++){
				if (partten_label[i][partten_dim] == 1.0){
					fw.write("1\t");
				}else{
					fw.write("2\t");
				}
				double[] tmp = partten_label[i];
				for (int j = 0; j < tmp.length - 1; j++){
					fw.write((j+1)+":"+df.format(tmp[j]) + "\t");
				}
				fw.write("\n");
			}
			fw.close();
		}
	
}
