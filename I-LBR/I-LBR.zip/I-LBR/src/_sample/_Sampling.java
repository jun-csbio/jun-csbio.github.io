package _sample;
import java.util.Date;
import java.util.Random;
import java.util.Vector;

import _util._Matrix;


public class _Sampling {
	
	// Random under sampling
	public static Vector<double[]> RUS(Vector<double[]> osams, int negaDivPosi){
		if (negaDivPosi <= 0)
			return osams;
		
		Vector<double[]> oposis = new Vector<double[]>();
		Vector<double[]> onegas = new Vector<double[]>();
		for (int i = 0; i < osams.size(); i++){
			double[] sam = osams.get(i);
			if (1.0 == sam[sam.length-1]){
				oposis.add(sam);
			}else{
				onegas.add(sam);
			}
		}
		
		Vector<double[]> ans = new Vector<double[]>();
		ans.addAll(oposis);
		
		Vector<double[]> select_negas = new Vector<double[]>();
        int posi_num = oposis.size();
        int nega_num = onegas.size();
        
        System.out.println("posi_num = " + posi_num);
        System.out.println("nega_num = " + nega_num);
        
        int select_nega_num = posi_num * negaDivPosi;
        if (select_nega_num < nega_num) {
        	Random r = new Random(new Date().getTime());
            for (int i = 0; i < select_nega_num; i++){
            	int pos = Math.abs(r.nextInt() % onegas.size());
            	select_negas.add(onegas.get(pos));
            	onegas.remove(pos);
            }
            
            ans.addAll(select_negas);
        } else {
        	ans.addAll(onegas);
        }
        
        return ans;
    } 
	
	// Random under-over sampling
	public static Vector<double[]> RUOS(Vector<double[]> osams, int newNegaDivOrigPosi, int newPosiDivOrigPosi){
		Vector<double[]> rus = RUS(osams, newNegaDivOrigPosi);
		Vector<double[]> ros = newROS(osams, newPosiDivOrigPosi);
		
		Vector<double[]> ans = new Vector<double[]>();
		{// 
			Vector<double[]> posis = new Vector<double[]>();
			Vector<double[]> negas = new Vector<double[]>();
			for (int i = 0; i < ros.size(); i++) {
				double[] sam = ros.get(i);
				if (1.0 == sam[sam.length - 1]) {
					posis.add(sam);
				} else {
					negas.add(sam);
				}
			}
			
			ans.addAll(posis);
			System.out.println("Posi sample number is " + posis.size());
		}
		{// 
			Vector<double[]> posis = new Vector<double[]>();
			Vector<double[]> negas = new Vector<double[]>();
			for (int i = 0; i < rus.size(); i++) {
				double[] sam = rus.get(i);
				if (1.0 == sam[sam.length - 1]) {
					posis.add(sam);
				} else {
					negas.add(sam);
				}
			}
			
			ans.addAll(negas);
			System.out.println("Nega sample number is " + negas.size());

		}
		
		return ans;
	} 
	
	// Random under sampling
	public static double[][] RUS(double[][] osams, int negaDivPosi) {
		if (negaDivPosi <= 0)
			return osams;

		Vector<double[]> oposis = new Vector<double[]>();
		Vector<double[]> onegas = new Vector<double[]>();
		for (int i = 0; i < osams.length; i++) {
			double[] sam = osams[i];
			if (1.0 == sam[sam.length - 1]) {
				oposis.add(sam);
			} else {
				onegas.add(sam);
			}
		}

		Vector<double[]> ans = new Vector<double[]>();
		ans.addAll(oposis);

		Vector<double[]> select_negas = new Vector<double[]>();
		int posi_num = oposis.size();
		int nega_num = onegas.size();
		int select_nega_num = posi_num * negaDivPosi;
		if (select_nega_num < nega_num) {
			Random r = new Random(new Date().getTime());
			for (int i = 0; i < select_nega_num; i++) {
				int pos = Math.abs(r.nextInt() % onegas.size());
				select_negas.add(onegas.get(pos));
				onegas.remove(pos);
			}

			ans.addAll(select_negas);
		} else {
			ans.addAll(onegas);
		}

		return _Matrix.exchangeVDArrToD2Arr(ans);
	} 
	
	// Random over sampling
	public static Vector<double[]> ROS(Vector<double[]> osams, int negaDivPosi){
		Vector<double[]> ans = new Vector<double[]>();
		
		Vector<double[]> oposis = new Vector<double[]>();
		Vector<double[]> onegas = new Vector<double[]>();
		for (int i = 0; i < osams.size(); i++){
			double[] sam = osams.get(i);
			if (1.0 == sam[sam.length-1]){
				oposis.add(sam);
			}else{
				onegas.add(sam);
			}
		}
		
		ans.addAll(oposis);
		ans.addAll(onegas);
		
		int nega_num = onegas.size();
		int sel_posi_num = (nega_num/negaDivPosi - oposis.size());
		Random r = new Random(new Date().getTime());
		for (int i = 0; i < sel_posi_num; i++){
			int pos = Math.abs(r.nextInt() % oposis.size());
			ans.add(oposis.get(pos));
		}
		
		return ans;
	}
	
	// New Random over sampling
	public static Vector<double[]> newROS(Vector<double[]> osams, int newPosiDivOrigPosi) {
		int fea_size = osams.get(0).length - 1;

		Vector<double[]> ans = new Vector<double[]>();

		Vector<double[]> oposis = new Vector<double[]>();
		Vector<double[]> onegas = new Vector<double[]>();
		for (int i = 0; i < osams.size(); i++) {
			double[] sam = osams.get(i);
			if (1.0 == sam[fea_size]) {
				oposis.add(sam);
			} else {
				onegas.add(sam);
			}
		}

		ans.addAll(oposis);
		ans.addAll(onegas);

		int posi_num = oposis.size();
		int sel_posi_num = (newPosiDivOrigPosi - 1) * posi_num;
		System.out.println("posi_num = " + posi_num);
		System.out.println("newPosiDivOrigPosi = " + newPosiDivOrigPosi);
		System.out.println(" sel_posi_num = " + sel_posi_num);
		Random r = new Random(19891007);
		for (int i = 0; i < sel_posi_num; i++) {
			int a_ind = r.nextInt(oposis.size());
			int b_ind = r.nextInt(oposis.size());
			int c_ind = r.nextInt(oposis.size());
			while (a_ind == b_ind || a_ind == c_ind || b_ind == c_ind) {
				a_ind = r.nextInt(oposis.size());
				b_ind = r.nextInt(oposis.size());
				c_ind = r.nextInt(oposis.size());
			}

			double[] a_sample = oposis.get(a_ind);
			double[] b_sample = oposis.get(b_ind);
			double[] c_sample = oposis.get(c_ind);

			double e = 0.3 * r.nextDouble();
			double[] new_sample = new double[fea_size + 1];
			for (int k = 0; k < fea_size; k++) {
				new_sample[k] = a_sample[k] + e * (b_sample[k] - c_sample[k]);
			}
			new_sample[fea_size] = 1.0;

			ans.add(new_sample);
		}

		return ans;
	}

}
