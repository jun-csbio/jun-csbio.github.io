package _reportParam;

import _util._NumFormat;
import _util._Str;

public class ConfusionMatrix {
	private int tp;
	private int fn;
	private int fp;
	private int tn;

	public ConfusionMatrix(){
		this.tp = 0;
		this.fn = 0;
		this.fp = 0;
		this.tn = 0;
	}
	
	public ConfusionMatrix(int tp, int fn, int fp, int tn) {
		this.tp = tp;
		this.fn = fn;
		this.fp = fp;
		this.tn = tn;
	}

	public ConfusionMatrix add(ConfusionMatrix a, ConfusionMatrix b) {
		ConfusionMatrix ans = new ConfusionMatrix(0, 0, 0, 0);
		ans.tp = a.tp + b.tp;
		ans.fn = a.fn + b.fn;
		ans.fp = a.fp + b.fp;
		ans.tn = a.tn + b.tn;
		return ans;
	}
	
	public void add(ConfusionMatrix a){
		tp += a.tp;
		fp += a.fp;
		tn += a.tn;
		fn += a.fn;
	}

	public void tp_plus(int a) {
		tp += a;
	}

	public void fn_plus(int a) {
		fn += a;
	}

	public void fp_plus(int a) {
		fp += a;
	}

	public void tn_plus(int a) {
		tn += a;
	}

	public int getTp() {
		return tp;
	}

	public int getFn() {
		return fn;
	}

	public int getFp() {
		return fp;
	}

	public int getTn() {
		return tn;
	}

	public double getMCC(){
		double fenmu = Math.sqrt(1.0*(tp+fp)*(tp+fn)*(tn+fp)*(tn+fn));
		fenmu = fenmu > 0 ? fenmu : 0.000001;
		return (tp*tn - fp*fn)/fenmu;
	}
	
	public double getTPR(){
		return (1.0*tp/(tp+fn));
	}
	
	public double getSen(){
		return (1.0*tp/(tp+fn));
	}
	
	public double getSpe(){
		return (1.0*tn/(fp+tn));
	}
	
	public double getAcc(){
		return 1.0*(tp + tn) / (tp + tn + fp + fn);
	}
	
	public double getPre(){
		return tp*1.0/(tp+fp);
	}
	
	public double getFPR(){
		return (1.0*fp/(fp+tn));
	}
	
	public int getTotal(){
		return tp+fp+tn+fn;
	}
	
	public String toString() {
		return "["
				+ tp + " " + fn
				+ "; \n"
				+ fp + " " + tn
				+ "]\n"
				+ "sen=" + _Str.replenishHeadWithSpace(_NumFormat.formatDouble(1.0*tp / (tp + fn), "#0.0000"), 6)
				+ "\n"
				+ "spe=" + _Str.replenishHeadWithSpace(_NumFormat.formatDouble(1.0*tn / (fp + tn), "#0.0000"), 6) 
				+ "\n"
				+ "acc=" + _Str.replenishHeadWithSpace(_NumFormat.formatDouble(1.0*(tp + tn) / (tp + tn + fp + fn), "#0.0000"), 6)
				+ "\n"
				+ "pre="+_Str.replenishHeadWithSpace(_NumFormat.formatDouble(tp*1.0/(tp+fp), "#0.0000"), 6)
				+ "\n"
				+ "mcc="+_Str.replenishHeadWithSpace(_NumFormat.formatDouble((tp*tn - fp*fn)/Math.sqrt(1.0*(tp+fp)*(tp+fn)*(tn+fp)*(tn+fn)), "#0.000"), 6);
	}
	
	public static void main(String[] args){
		ConfusionMatrix cm = new ConfusionMatrix(875, 0, 201, 21200);
		System.out.println(cm.getMCC());
	}
}
