package _reportParam;

import java.io.BufferedReader;
import java.io.FileReader;
import java.util.Vector;

import _util._Matrix;
import _util._Vector;

public class ParamCalculator {

	public static double maxMCCThreshold(String junh_format_libsvm_res_file_path){
		double max_mcc = Double.MIN_VALUE;
		double max_threshold = 0.0;
		double step = 0.02;
		for (double i = 0.0; i <= 1; i+=step){
			ConfusionMatrix tmp = getConfusionMatrix(junh_format_libsvm_res_file_path, i);
			double mcc = tmp.getMCC();
			if (mcc > max_mcc){
				max_mcc = mcc;
				max_threshold = i;
			}
		}
		
		
		return max_threshold;
	}
	
	public static double maxMCCThreshold_Type2(String junh_format_libsvm_res_file_path){
		double max_mcc = Double.MIN_VALUE;
		double max_threshold = 0.0;
		double step = 0.01;
		for (double i = -1.5; i <= 1.5; i+=step){
			ConfusionMatrix tmp = getConfusionMatrix(junh_format_libsvm_res_file_path, i);
			double mcc = tmp.getMCC();
			if (mcc > max_mcc){
				max_mcc = mcc;
				max_threshold = i;
			}
		}
		
		
		return max_threshold;
	}
	
	public static double maxMCCThreshold(Vector<double[]> libsvm_junh_res){
		double max_mcc = Double.MIN_VALUE;
		double max_threshold = 0.0;
		double step = 0.02;
		for (double i = 0.0; i <= 1; i+=step){
			ConfusionMatrix tmp = getConfusionMatrix(libsvm_junh_res, i);
			double mcc = tmp.getMCC();
			if (mcc > max_mcc){
				max_mcc = mcc;
				max_threshold = i;
			}
		}
		
		
		return max_threshold;
	}
	
	public static double getMaxMCC(Vector<double[]> libsvm_junh_res){
		double max_mcc = Double.MIN_VALUE;
		double step = 0.01;
		for (double i = 0.0; i <= 1; i+=step){
			ConfusionMatrix tmp = getConfusionMatrix(libsvm_junh_res, i);
			double mcc = tmp.getMCC();
			if (mcc > max_mcc){
				max_mcc = mcc;
			}
		}
		
		
		return max_mcc;
	}
	
	public static ConfusionMatrix getConfusionMatrix(String junh_format_libsvm_res_file_path, double threshold){
		ConfusionMatrix ans = new ConfusionMatrix(0,0,0,0);
		try{
			double[][] res = _Matrix.loadMatrix(junh_format_libsvm_res_file_path);
			
			for (int i = 0; i < res.length; i++){
				if (1 == res[i][0]){
					if (res[i][1] >= threshold){
						ans.tp_plus(1);
					}else{
						ans.fn_plus(1);
					}
				}else{
					if (res[i][1] >= threshold){
						ans.fp_plus(1);
					}else{
						ans.tn_plus(1);
					}
				}
			}
		}catch(Exception e){
			e.printStackTrace();
		}
		
		return ans;
	}
	
	public static ConfusionMatrix getConfusionMatrix(Vector<double[]> res, double threshold){
		ConfusionMatrix ans = new ConfusionMatrix(0,0,0,0);
		try{
			for (int i = 0; i < res.size(); i++){
				if (1 == res.get(i)[0]){
					if (res.get(i)[1] >= threshold){
						ans.tp_plus(1);
					}else{
						ans.fn_plus(1);
					}
				}else{
					if (res.get(i)[1] >= threshold){
						ans.fp_plus(1);
					}else{
						ans.tn_plus(1);
					}
				}
			}
		}catch(Exception e){
			e.printStackTrace();
		}
		
		return ans;
	}
	
	public static double getAUCValue(Vector<double[]> res){
		Vector<Double> tprs = new Vector<Double>();
		Vector<Double> fprs = new Vector<Double>();
		
		double step = 0.001;
		for (double i = 0.0; i <= 1; i+=step){
			ConfusionMatrix tmp = getConfusionMatrix(res, i);
			tprs.add(tmp.getTPR());
			fprs.add(tmp.getFPR());
		}
		
		int size = fprs.size();
		double area = 0.0;
		for (int i = 0; i < size-1; i++){
			area += Math.abs((fprs.get(i+1)-fprs.get(i))*(tprs.get(i+1)+tprs.get(i))/2);
		}
		
		return area;
	}
	
	public static double getAUCValue(String junh_format_libsvm_res_file_path){
		Vector<Double> tprs = new Vector<Double>();
		Vector<Double> fprs = new Vector<Double>();
		
		double step = 0.001;
		for (double i = 0.0; i <= 1; i+=step){
			ConfusionMatrix tmp = getConfusionMatrix(junh_format_libsvm_res_file_path, i);
			tprs.add(tmp.getTPR());
			fprs.add(tmp.getFPR());
		}
		
		int size = fprs.size();
		double area = 0.0;
		for (int i = 0; i < size-1; i++){
			area += Math.abs((fprs.get(i+1)-fprs.get(i))*(tprs.get(i+1)+tprs.get(i))/2);
		}
		
		return area;
	}
	
	public static double getAUCValue(String junh_format_libsvm_res_file_path, double min_thres_value, double max_thres_value){
		Vector<Double> tprs = new Vector<Double>();
		Vector<Double> fprs = new Vector<Double>();
		
		double step = 0.001;
		for (double i = min_thres_value; i <= max_thres_value; i+=step){
			ConfusionMatrix tmp = getConfusionMatrix(junh_format_libsvm_res_file_path, i);
			tprs.add(tmp.getTPR());
			fprs.add(tmp.getFPR());
		}
		
		int size = fprs.size();
		double area = 0.0;
		for (int i = 0; i < size-1; i++){
			area += Math.abs((fprs.get(i+1)-fprs.get(i))*(tprs.get(i+1)+tprs.get(i))/2);
		}
		
		return area;
	}
	
	public static double getAUCValue_Type2(String junh_format_libsvm_res_file_path){
		Vector<Double> tprs = new Vector<Double>();
		Vector<Double> fprs = new Vector<Double>();
		
		double step = 0.01;
		for (double i = -1.5; i <= 1.5; i+=step){
			ConfusionMatrix tmp = getConfusionMatrix(junh_format_libsvm_res_file_path, i);
			tprs.add(tmp.getTPR());
			fprs.add(tmp.getFPR());
		}
		
		int size = fprs.size();
		double area = 0.0;
		for (int i = 0; i < size-1; i++){
			area += Math.abs((fprs.get(i+1)-fprs.get(i))*(tprs.get(i+1)+tprs.get(i))/2);
		}
		
		return area;
	}
	
	/**
	 * @param sortedPredRes : each line content is : ligand_id\tscore\n
	 * @param trueLigIDs : the true interacted ligand ids
	 * @param totalNumOfAllDatabaseLigs : the total number of all used ligands database.
	 * @param x : the x ratio e.g., 0.005 (i.e., 0.5%), 0.01 (i.e., 1%)
	 * @return the EFx value 
	 * @throws Exception
	 */
	public static double getEFx(String sortedPredRes, Vector<String> trueLigIDs,  int totalNumOfAllDatabaseLigs, double x)throws Exception{
		int total_num_tp = trueLigIDs.size();
		int num_of_tp_within_top_x = 0;
		
		int readLineNum = (int)(totalNumOfAllDatabaseLigs * x);
		BufferedReader br = new BufferedReader(new FileReader(sortedPredRes));
		String l = br.readLine();
		while (null != l && readLineNum >= 0){
			String[] lc = l.split("\t");
			if (_Vector.isContain(trueLigIDs, lc[0])){
				num_of_tp_within_top_x++;
			}
			
			readLineNum--;
			l = br.readLine();
		}
		br.close();
		
		return 1.0*num_of_tp_within_top_x / (total_num_tp * x);
	}
	
	/**
	 * @param VSTopXPercentLigIDs : each element is ligand fingerprint.\n
	 * @param trueLigIDs : the true interacted ligand ids
	 * @param N_T: the total ligand num in ligand library
	 * @return the Enrichment Factor value : 
	 * 			(Hits_S / N_S) / (Hits_T / N_T)
	 * 			where 	N_S is selected the top best ligand number, 
	 * 					Hits_S is true positive number in the selected N_S ligands.
	 * 					N_T is the total ligand number in the search ligand library
	 * 					Hits_T is the true positive number in the N_T ligands. 
	 */
	public static double getEFx(String[] VSTopXPercentLigIDs, Vector<String> trueLigFpts, int N_T){
		int Hits_T = trueLigFpts.size();
		int N_S = VSTopXPercentLigIDs.length;
		
		int Hits_S = 0;
		for (int i = 0; i < N_S; i++){
			if (_Vector.isContain(trueLigFpts, VSTopXPercentLigIDs[i])){
				Hits_S++;
			}
		}
		
		System.out.println("("+Hits_S + "/" + N_S +") / (" +Hits_T+"/"+ N_T+")");
		return (1.0*Hits_S / N_S) / (1.0*Hits_T / N_T);
	}
	
	/*public static void main(String[] args){
		System.out.println(getAUCValue("/home/ddy/ScholarWorkSpace/FlankATP/227/ATPlabel_Validation.txt.PSIBLAT_PSSM.N4W17top0libsvm_junh_format_test_res"));
	}*/
}
