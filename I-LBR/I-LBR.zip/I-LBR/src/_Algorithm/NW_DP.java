package _Algorithm;

import java.util.Vector;

import _util._Str;

public class NW_DP {
	// you know, each program has some constrains, the NW_DP program's
	// constrains were wrote in
	// "A General Method Applicable to the Search for Similarities in the Amino
	// Acid Sequence of Two Proteins "

	public static void main(String[] args) {
		// TODO Auto-generated method stub
		String seqA = "14211124111111211111115151515151111111111111";
		String seqB = "142111111111111111515151515124111111112411";
		
//		String seqA = "14211124111111211111115151515151111111111111";
//		String seqB = "142111111111111111515151515124111111112411";
		int[] ans = NW_DP.searchTwoSeqAlign(seqA, seqB, null, -0.5);
		for (int i = 0; i < ans.length-1; i++){
			System.out.print(_Str.replenishEndWithSpace(i+"", 3)+" ");
		}
		System.out.println();
		for (int i = 0; i < ans.length-1; i++){
			System.out.print(_Str.replenishEndWithSpace(seqA.charAt(i)+"", 3)+" ");
		}
		System.out.println();
		for (int i = 0; i < ans.length-1; i++){
			if (ans[i] == -1)
				System.out.print(_Str.replenishEndWithSpace("-", 3)+" ");
			else System.out.print(_Str.replenishEndWithSpace(seqB.charAt(ans[i]) + "", 3)+" ");
		}
		System.out.println();
		for (int i = 0; i < ans.length-1; i++){
			System.out.print(_Str.replenishEndWithSpace(ans[i]+"", 3)+" ");
		}
	}

	/**
	 * @param seqA
	 *            : the object A sequence information, length len1
	 * @param seqB
	 *            : the object B sequence information, length len2
	 * @param scores
	 *            : scores[i][j] means the similarity between the i-th element
	 *            in seqA with the j-th element in seqB. If this parameter is null, 1 is default for each element.
	 * @param gap_open
	 *            : the gap open penalty cost
	 * @return the align information, "ans[i]" means the i-th element in seqA is
	 *         aligned with the ans[i]-th element in seqB
	 * @description: copy from TMalign
	 */
	public static int[] searchTwoSeqAlign(String seqA, String seqB, double[][] scores, double gap_open) {
		int len1 = seqA.length();
		int len2 = seqB.length();

		int[] ans = new int[len1 + 1];
		double[][] val = new double[len1 + 1][len2 + 1];
		boolean[][] path = new boolean[len1 + 1][len2 + 1];

		int i, j;
		double h, v, d;

		// initialization
		val[0][0] = 0;
		for (i = 0; i <= len1; i++) {
			val[i][0] = 0;
			path[i][0] = false; // not from diagonal
			ans[i] = -1; // all are not aligned, 
		}

		for (j = 0; j <= len2; j++) {
			val[0][j] = 0;
			path[0][j] = false; // not from diagonal
		}

		// decide matrix and path
		for (i = 1; i <= len1; i++) {
			for (j = 1; j <= len2; j++) {
				// d=val[i-1][j-1]+score[i][j]; //diagonal
				if (seqA.charAt(i - 1) == seqB.charAt(j - 1)) {
					if (null == scores)
						d = val[i - 1][j - 1] + 1.0;
					else
						d = val[i - 1][j - 1] + scores[i - 1][j - 1];
				} else {
					d = val[i - 1][j - 1];
				}

				// symbol insertion in horizontal (= a gap in vertical)
				h = val[i - 1][j];
				if (path[i - 1][j]) // aligned in last position
					h += gap_open;

				// symbol insertion in vertical
				v = val[i][j - 1];
				if (path[i][j - 1]) // aligned in last position
					v += gap_open;

				if (d >= h && d >= v) {
					path[i][j] = true; // from diagonal
					val[i][j] = d;
				} else {
					path[i][j] = false; // from horizontal
					if (v >= h)
						val[i][j] = v;
					else
						val[i][j] = h;
				}
			} // for i
		} // for j

		// trace back to extract the alignment
		i = len1;
		j = len2;
		while (i > 0 && j > 0) {
			if (path[i][j]) // from diagonal
			{
				ans[i - 1] = j - 1;
				i--;
				j--;
			} else {
				h = val[i - 1][j];
				if (path[i - 1][j])
					h += gap_open;

				v = val[i][j - 1];
				if (path[i][j - 1])
					v += gap_open;

				if (v >= h)
					j--;
				else
					i--;
			}
		}
		
		return ans;
	}

	/**
	 * @param scores
	 *            : scores[i][j] means the similarity between the orginal i-th element
	 *            in the first Object with the original j-th element in the second object. 
	 * @param gap_open
	 *            : the gap open penalty cost
	 * @return the align information, "ans[i]" means the i-th element in seqA is
	 *         aligned with the ans[i]-th element in seqB, the last index is invalid
	 * @description: copy from TMalign
	 */
	public static int[] searchTwoSeqAlign(double[][] scores, double gap_open) {
		int len1 = scores.length;
		int len2 = scores[0].length;

		int[] ans = new int[len1 + 1];
		double[][] val = new double[len1 + 1][len2 + 1];
		boolean[][] path = new boolean[len1 + 1][len2 + 1];

		int i, j;
		double h, v, d;

		// initialization
		val[0][0] = 0;
		for (i = 0; i <= len1; i++) {
			val[i][0] = 0;
			path[i][0] = false; // not from diagonal
			ans[i] = -1; // all are not aligned, 
		}

		for (j = 0; j <= len2; j++) {
			val[0][j] = 0;
			path[0][j] = false; // not from diagonal
		}

		// decide matrix and path
		for (i = 1; i <= len1; i++) {
			for (j = 1; j <= len2; j++) {
				d=val[i-1][j-1] +  scores[i - 1][j - 1];
				
				// symbol insertion in horizontal (= a gap in vertical)
				h = val[i - 1][j];
				if (path[i - 1][j]) // aligned in last position
					h += gap_open;

				// symbol insertion in vertical
				v = val[i][j - 1];
				if (path[i][j - 1]) // aligned in last position
					v += gap_open;

				if (d >= h && d >= v) {
					path[i][j] = true; // from diagonal
					val[i][j] = d;
				} else {
					path[i][j] = false; // from horizontal
					if (v >= h)
						val[i][j] = v;
					else
						val[i][j] = h;
				}
			} // for i
		} // for j

		// trace back to extract the alignment
		i = len1;
		j = len2;
		while (i > 0 && j > 0) {
			if (path[i][j]) // from diagonal
			{
				ans[i - 1] = j - 1;
				i--;
				j--;
			} else {
				h = val[i - 1][j];
				if (path[i - 1][j])
					h += gap_open;

				v = val[i][j - 1];
				if (path[i][j - 1])
					v += gap_open;

				if (v >= h)
					j--;
				else
					i--;
			}
		}
		
		return ans;
	}
	
	/**
	 * @param rowInds : means the row index of scores, notice is sorted.
	 * @param colInds : means the row index of scores, notice is sorted.
	 * @param scores
	 *            : scores[i][j] means the similarity between the orginal i-th element
	 *            in the first Object with the original j-th element in the second object. 
	 * @param gap_open
	 *            : the gap open penalty cost
	 * @return the align information, "ans[i]" means the i-th element in seqA is
	 *         aligned with the ans[i]-th element in seqB, the last index is invalid
	 * @description: copy from TMalign
	 */
	public static int[] searchTwoSeqAlign(Vector<Integer> rowInds, Vector<Integer> colInds, double[][] scores, double gap_open) {
		int len1 = scores.length;
		int len2 = scores[0].length;

		int[] ans = new int[len1 + 1];
		double[][] val = new double[len1 + 1][len2 + 1];
		boolean[][] path = new boolean[len1 + 1][len2 + 1];

		int i, j;
		double h, v, d;

		// initialization
		val[0][0] = 0;
		for (i = 0; i <= len1; i++) {
			val[i][0] = 0;
			path[i][0] = false; // not from diagonal
			ans[i] = -1; // all are not aligned, 
		}

		for (j = 0; j <= len2; j++) {
			val[0][j] = 0;
			path[0][j] = false; // not from diagonal
		}

		// decide matrix and path
		for (i = 1; i <= len1; i++) {
			for (j = 1; j <= len2; j++) {
				d=val[i-1][j-1] +  scores[rowInds.get(i - 1)][colInds.get(j - 1)];
				
				// symbol insertion in horizontal (= a gap in vertical)
				h = val[i - 1][j];
				if (path[i - 1][j]) // aligned in last position
					h += gap_open;

				// symbol insertion in vertical
				v = val[i][j - 1];
				if (path[i][j - 1]) // aligned in last position
					v += gap_open;

				if (d >= h && d >= v) {
					path[i][j] = true; // from diagonal
					val[i][j] = d;
				} else {
					path[i][j] = false; // from horizontal
					if (v >= h)
						val[i][j] = v;
					else
						val[i][j] = h;
				}
			} // for i
		} // for j

		// trace back to extract the alignment
		i = len1;
		j = len2;
		while (i > 0 && j > 0) {
			if (path[i][j]) // from diagonal
			{
				ans[rowInds.get(i - 1)] = colInds.get(j - 1);
				i--;
				j--;
			} else {
				h = val[i - 1][j];
				if (path[i - 1][j])
					h += gap_open;

				v = val[i][j - 1];
				if (path[i][j - 1])
					v += gap_open;

				if (v >= h)
					j--;
				else
					i--;
			}
		}
		
		return ans;
	}
	
}
