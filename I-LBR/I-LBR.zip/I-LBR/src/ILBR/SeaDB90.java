package ILBR;

import java.io.BufferedReader;
import java.io.File;
import java.io.FileReader;
import java.io.FileWriter;
import java.util.Date;
import java.util.HashMap;
import java.util.Vector;

import _Algorithm.NW_DP;
import _runner.Blastpgp;
import _runner.PSIPREDRunner;
import _runner.SANNRunner;
import _util.BLOSUM62;
import _util.ConfigUtil;
import _util.NWAlign;
import _util._File;
import _util._Log;
import _util._NumFormat;
import _util._Sort;

/*******************************************************************************
 * Using PSSM, PSS, PSA to search the SeaSite-specific BioLip90 (<90% sequence 
 * identity) database, respectively.
 *******************************************************************************/
public class SeaDB90{
	private String q_protname;				// the name of the query protein
	private String q_protseq;				// the sequence of the query protein
	private double seqid_cutoff	= 0.3;		// the sequence identity cutoff value (default 0.3)
	private String queryligtypes;			// " ATP ADP ... CA "
	private double[][] q_psfm;				// position-specific frequency matrix (PSFM)
	private double[] q_jsd;
	private double[][] q_orig_pssm;			// the original pssm of the query protein using PSI-BLAST
	private double[][] q_pss_prob;			// the secondary structure probability of the query protein using PSIPRED software
	private double[][] q_psa_prob;			// the solvent accessibility probability of the query protein using SANN software
	
	// return Search Result
	private HashMap<String, StringBuffer> SeaRes;	// S(i, j) = sum_{k=1}^{20} (pssm_{i, k} * pssm_{j, k})
													// key = protname; value = BSITEs, e.g., 
													// 1exf_ATP_A_1#23 24 26 102CSBIONJUST1exf_ADP_A_1#12 24 (index start from 0)
	private double[] voteProb = null;				// Directly voting result
	
	private double w_pssm;
	private double w_pss;
	private double w_psa;
	private double w_blosum;
	private double ali_gap_penalty;
	private double w_g_As;
	private double w_l_As;
	private double w_Ls;
	private double w_JSD;
	
	public SeaDB90(String q_protname, String q_protseq, double seqid_cutoff, String queryligtypes, double[][] q_psfm, double[] q_jsd,
			double[][] q_orig_pssm, double[][] q_pss_prob, double[][] q_psa_prob,
			double w_pssm, double w_pss, double w_psa, double w_blosum, double ali_gap_penalty,
			double w_g_As, double w_l_As, double w_Ls, double w_JSD)throws Exception{
		this.q_protname = q_protname;
		this.q_protseq = q_protseq;
		this.seqid_cutoff = seqid_cutoff;
		this.queryligtypes = queryligtypes;
		this.q_psfm = q_psfm;
		this.q_jsd = q_jsd;
		this.q_orig_pssm = q_orig_pssm;
		this.q_pss_prob = q_pss_prob;
		this.q_psa_prob = q_psa_prob;
		
		this.w_pssm = w_pssm;
		this.w_pss = w_pss;
		this.w_psa = w_psa;
		this.w_blosum = w_blosum;
		this.ali_gap_penalty = ali_gap_penalty;
		this.w_g_As = w_g_As;
		this.w_l_As = w_l_As;
		this.w_Ls = w_Ls;
		this.w_JSD = w_JSD;
		
		doSea();
	}
	
	public HashMap<String, StringBuffer> getSeaRes() {
		return SeaRes;
	}

	public double[] getVoteProb() {
		return voteProb;
	}
	
	private void generateFeas(String siteseaDBFolder, String protname, String protseq) {
		
		if (!new File(siteseaDBFolder + "/PSSM/").exists()) {
			new File(siteseaDBFolder + "/PSSM/").mkdirs();
		}
		if (!new File(siteseaDBFolder + "/PSS/").exists()) {
			new File(siteseaDBFolder + "/PSS/").mkdirs();
		}
		if (!new File(siteseaDBFolder + "/PSA/").exists()) {
			new File(siteseaDBFolder + "/PSA/").mkdirs();
		}
		
		try {
			String pssm_path = siteseaDBFolder + "/PSSM/"+protname+".pssm";
			String pss_path = siteseaDBFolder + "/PSS/"+protname+".pss";
			String psa_path = siteseaDBFolder + "/PSA/"+protname+".psa";
			
			Blastpgp blastpgp = null;
			String save_psitmp_chk = pssm_path+".psitmp.chk";
			String save_blast_out = pssm_path+".blast.out";
			if (!new File(pssm_path).isFile()){
				System.out.println(protname + "'s PSSM is generating...");
				blastpgp = new Blastpgp(protname, protseq, FixParam.BLASTPGP_B, FixParam.BLASTPGP_J, FixParam.BLSATPGP_H,
						pssm_path, save_psitmp_chk, save_blast_out);
			}
			
			PSIPREDRunner psipred = null;
			if (!new File(pss_path).isFile()){
				System.out.println(protname + "'s PSS is generating...");
				psipred = new PSIPREDRunner(protname, protseq, blastpgp, siteseaDBFolder + "/PSS/");
				_File.copy(psipred.getSaveSSPath(), pss_path);
				new File(psipred.getSaveSSPath()).delete();
			}
			
			if (new File(save_psitmp_chk).isFile()) {
				new File(save_psitmp_chk).delete();
			}
			if (new File(save_blast_out).isFile()) {
				new File(save_blast_out).delete();
			}
			
			String save_sann_psa = psa_path;
			if (!new File(save_sann_psa).isFile()){
				System.out.println(protname + "'s PSA is generating...");
				if (protseq.length() < 1280){
					new SANNRunner(protname, protseq, save_sann_psa);	
				}else{
					int num = 6;
					int step = protseq.length() / num;
					int mod = protseq.length() % num;
					
					FileWriter fw = new FileWriter(save_sann_psa);
					for (int f = 0; f < num; f++){
						System.out.println(f+" ");
						int start_tst_index;
						int end_tst_index;
						if (f < mod){
							start_tst_index = f*step + f;
							end_tst_index = ((f+1)*step>protseq.length() ? protseq.length() : (f+1)*step) + (f+1);
						}else{
							start_tst_index = f*step + mod;
							end_tst_index = ((f+1)*step>protseq.length() ? protseq.length() : (f+1)*step) + mod;
						}
						
						new SANNRunner(protname, protseq.substring(start_tst_index, end_tst_index), save_sann_psa+"_"+f);
						
						String fth_sa = _File.load2Str(save_sann_psa+"_"+f);
						if (0==f){
							fw.write(fth_sa.trim()+"\n");
						}else{
							String[] fth_sa_lc = fth_sa.trim().split("\n");
							for (int i = 2; i < fth_sa_lc.length; i++){
								fw.write(fth_sa_lc[i]+"\n");
							}
						}
						new File(save_sann_psa+"_"+f).delete();
					}
					fw.close();
				}
			}
		}catch (Exception e) {
			e.printStackTrace();
		}
	}

	private void doSea()throws Exception{
		String siteseaDBFolder = ConfigUtil.getConfig("SITESEA_DB_FOLDER");
		if (null == siteseaDBFolder || !new File(siteseaDBFolder).exists()){
			System.out.println("Please check the config file items : SITESEA_DB_FOLDER");
			_Log.dayRunLog("Please check the config file items : SITESEA_DB_FOLDER", new Date());
			System.exit(-1);
		}
		
		Vector<Double> sco_vec = new Vector<Double>();
		Vector<String> poc_vec = new Vector<String>();	// value = protname#LigType#BSITES, 
														// e.g., 1xefA#ATP#12 13 15 (index start from 0)
		Vector<Vector<Integer>>  q_aliBSITE_Ind_vec = new Vector<Vector<Integer>>(); 	// the residue indexes in query,
																	    					// which is aligned the binding sites of template.
		
//protname : Sequence : pocket_file_name#LigType#BSITES$pocket_ID#LigType#BSITES$...$pocket_ID#LigType#BSITES
//1xefA : MHH...KKW : 1exf_ATP_A_1#ATP#12 13 14$1exf_ATP_A_2#ATP#102 103 (bsites index is start from 1)
		String db_info_list = siteseaDBFolder + "/BSITE_info_cd90.list";
		BufferedReader br = new BufferedReader(new FileReader(db_info_list));
		String l = br.readLine();
		while (null != l){
			String[] lc = l.split(" : ");
			String protname = lc[0];
			String protseq = lc[1];
			String protBsites = lc[2];
			
			String pssm_path = siteseaDBFolder + "/PSSM/"+protname+".pssm";
			String pss_path = siteseaDBFolder + "/PSS/"+protname+".pss";
			String psa_path = siteseaDBFolder + "/PSA/"+protname+".psa";
			//-------------------------------------------------------------//
			//---   If three file all exist we do the following steps  ----//		
			//-------------------------------------------------------------//
			if (!new File(pssm_path).isFile() || !new File(pss_path).isFile() || !new File(psa_path).isFile()){
				generateFeas(siteseaDBFolder, protname, protseq);
				
				if (!new File(pssm_path).isFile() || !new File(pss_path).isFile() || !new File(psa_path).isFile()){
					l = br.readLine();
					continue;
				}
			}
			
			//-------------------------------------------------------------//
			//------- Using NWalign to cut the sequence identity  ---------//
			//-------------------------------------------------------------//
			NWAlign nwali = new NWAlign(q_protname, q_protseq, protname, protseq);
			double seqid = nwali.getSeqIdenticalNorm8MaxSeqLen();
			
			if (seqid > seqid_cutoff){
				l = br.readLine();
				continue;
			}
			
			double[][] orig_pssm = _File.loadMatrix(pssm_path);
			double[][] pss_prob = _File.loadPsipredPSS(pss_path);
			double[][] psa_prob = null;
			try{
				psa_prob = _File.loadSANNa3(psa_path);
			}catch(Exception e){
				System.out.println("Hey! !!!");
				System.out.println(psa_path);
				e.printStackTrace();
//				new File(psa_path).delete();
				l = br.readLine();
				continue;
			}
			
			//------------------------------------------------------------------------------//
			//------- Calculate Global score                                          ------//		
			//------------------------------------------------------------------------------//
			double[][] global_sco_mtx = new double[orig_pssm.length][q_orig_pssm.length];
			for (int j = 0; j < orig_pssm.length; j++){
				for (int k = 0; k < q_orig_pssm.length; k++){
					double pssm_sco_item = 0.0;
					for (int h = 0; h < 20; h++){
						pssm_sco_item += orig_pssm[j][h] * q_psfm[k][h];
					}
					
					double pss_sco_item = 0.0;
					for (int h = 0; h < 3; h++){
						pss_sco_item += pss_prob[j][h] * q_pss_prob[k][h];
					}
					
					double psa_sco_item = 0.0;
					for (int h = 0; h < 3; h++){
						psa_sco_item += psa_prob[j][h] * q_psa_prob[k][h];
					}
					
					global_sco_mtx[j][k] = w_pssm * pssm_sco_item + w_pss * pss_sco_item + w_psa * psa_sco_item; 
				}
			}
			
			//------------------------------------------------------------------------------//
			//------- Calculate  local (Pocket) score                                 ------//		
			//------------------------------------------------------------------------------//
			String[] protBsite_arr = protBsites.split("CSBIONJUST");
			
			for (int i = 0; i < protBsite_arr.length; i++){
				String[] tmp_lc = protBsite_arr[i].split("#");
				String poc_id = tmp_lc[0];
				String lig_type = tmp_lc[1];
				String[] bsites = tmp_lc[2].split(" ");
				
				double[][] total_sco_mtx = new double[orig_pssm.length][q_orig_pssm.length];
				for (int j = 0; j < orig_pssm.length; j++){
					for (int k = 0; k < q_orig_pssm.length; k++){
						total_sco_mtx[j][k] = global_sco_mtx[j][k];
					}
				}
				for (int j = 0; j < bsites.length; j++){
					int ind = Integer.parseInt(bsites[j]) - 1;
					for (int k = 0; k < q_orig_pssm.length; k++){
						double blosum_sco_item = BLOSUM62.getNorm(protseq.charAt(ind), q_protseq.charAt(k));
						total_sco_mtx[ind][k] += w_blosum * blosum_sco_item;
					}
				}
				
				Vector<Integer> bsites_aligned_queryInd = new Vector<Integer>();
				
				int[] ali = NW_DP.searchTwoSeqAlign(total_sco_mtx, ali_gap_penalty);
				
				
				double g_As = 0.0;	// global As
				double l_As = 0.0;	// local As
				double Lc = 0.0;
				double Ls = 0.0;
				double JSD = 0.0;
				for (int j = 0; j < protseq.length(); j++){
					if (-1 != ali[j]){
						g_As += total_sco_mtx[j][ali[j]];
					}
				}
				g_As /= q_protseq.length();
				
				StringBuffer poc_info = new StringBuffer(protname+"#"+poc_id+"#");
				int aligned_bsites = 0;
				for (int j = 0; j < bsites.length; j++){
					int ind = Integer.parseInt(bsites[j]) - 1;
					poc_info.append(ind + " ");
					
					if (-1 != ali[ind]){
						bsites_aligned_queryInd.add(ali[ind]);
						l_As += total_sco_mtx[ind][ali[ind]];
						aligned_bsites++;
						Ls += BLOSUM62.getNorm(protseq.charAt(ind), q_protseq.charAt(ali[ind]));
						JSD += q_jsd[ali[ind]];
					}
				}
				l_As /= aligned_bsites == 0 ? Double.MIN_VALUE : aligned_bsites; 
				Lc = 1.0 * aligned_bsites / bsites.length;
				Ls /= aligned_bsites == 0 ? Double.MIN_VALUE : aligned_bsites;
				JSD /= aligned_bsites == 0 ? Double.MIN_VALUE : aligned_bsites;
				
				double sco_seq = 2.0 / (1+Math.exp(-(w_g_As*g_As + Lc*(w_l_As*l_As+w_Ls*Ls+w_JSD*JSD)))) - 1;
				
//				System.out.println(protname + " is processed. it's scores are [As, Lc, Ls, JSD, final] = ["
//						+_NumFormat.formatDouble(g_As, "#0.000")+", "
//						+_NumFormat.formatDouble(l_As, "#0.000")+", "
//						+_NumFormat.formatDouble(Lc, "#0.000")+", "
//						+_NumFormat.formatDouble(Ls, "#0.000")+", "
//						+_NumFormat.formatDouble(JSD, "#0.000")+", "
//						+_NumFormat.formatDouble(sco_seq, "#0.000")+ "]");
				
				//========================================================================
				// ligand special template selection, we just give higher weight to 
				// special ligand
				//========================================================================
				if (null != queryligtypes 	
						&& null != lig_type
						&& (" " + queryligtypes.trim() + " ").contains(" "+lig_type+" ")){
					sco_seq += 1.0;
				}
				
				sco_vec.add(sco_seq);
				q_aliBSITE_Ind_vec.add(bsites_aligned_queryInd);
				poc_vec.add(poc_info.toString().trim());
			}
				
			l = br.readLine();
		}
		br.close();
		
		// select the top X template pockets 
		int[] indexes = _Sort.insertDescendSortIndex(sco_vec, 200);	// select the top 100 pockets
		int min_top_templ_poc_num = 20;
		if (null == SeaRes)
			SeaRes = new HashMap<String, StringBuffer>();
		for (int i = 0; i < indexes.length; i++){
			int ind = indexes[i];
			
			double thresh_cut = 0.5;
			if (null != queryligtypes) {
				thresh_cut = 1.5;
			}
			
			if (i >= min_top_templ_poc_num && sco_vec.get(ind) < thresh_cut)
				continue;
			
			String poc = poc_vec.get(ind);
			String[] poc_lc = poc.split("#");
			
			String protname = poc_lc[0];
			String poc_id = poc_lc[1];
			String poc_bsites = poc_lc[2];
			
			StringBuffer tmp = SeaRes.get(protname);
			if (null == tmp){
				tmp = new StringBuffer(poc_id+"#"+_NumFormat.formatDouble(sco_vec.get(ind), "#0.000")+"#"+poc_bsites);
			}else{
				// Here "CSBIONJUST" just a split word
				tmp.append("CSBIONJUST"+poc_id+"#"+_NumFormat.formatDouble(sco_vec.get(ind), "#0.000")+"#"+poc_bsites);
			}
			
			System.out.println(poc_id+"#"+_NumFormat.formatDouble(sco_vec.get(ind), "#0.000")+"#"+poc_bsites);
			SeaRes.put(protname, tmp);
		}
		
		
		if (null == voteProb)
			voteProb = new double[q_protseq.length()];
		for (int i = 0; i < indexes.length; i++){
			int ind = indexes[i];
			Vector<Integer> q_aliBSITE_Inds = q_aliBSITE_Ind_vec.get(ind);
			for (int j = 0; j < q_aliBSITE_Inds.size(); j++){
				int q_ind = q_aliBSITE_Inds.get(j);
				voteProb[q_ind]++;
			}
		}
		for (int i = 0; i < voteProb.length; i++)
			voteProb[i] /= indexes.length;
		
	}
}