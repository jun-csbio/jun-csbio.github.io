package ILBR;

public class FixParam {
	public static final int BLASTPGP_B = 1000;
	public static final int BLASTPGP_J = 3;
	public static final double BLSATPGP_H = 0.001;
}
