package ILBR;

import java.io.BufferedReader;
import java.io.File;
import java.io.FileReader;
import java.io.FileWriter;
import java.util.Date;
import java.util.HashMap;
import java.util.Vector;

import _fea.SeqFea;
import _implement.PSFMandJSD;
import _runner.Blastpgp;
import _runner.LIBSVMRunner;
import _runner.PSIPREDRunner;
import _runner.SANNRunner;
import _sample.SampleSaved;
import _sample._Sampling;
import _util.ConfigUtil;
import _util._File;
import _util._Log;
import _util._Matrix;
import _util._NumFormat;
import _util._Str;


/***********************************************************************************************
 * I-LBR-GP: Only protein sequence is given.
 * I-LBR-LS: Both protein sequence and ligand type(s) are given, the ligand type predicted 
 *                model exists. 
 **********************************************************************************************/
public class ILBR {
	// input
	private String queryname;
	private String queryseq; 			// without space and "\r" or "\n"
	private String queryligtypes;		// e.g., "ATP ADP CA ... III" or null
	private double idcut = 0.3;			// sequence identity cutoff (default is 0.3) 
	private String savefolder;
	private Integer imbalance_param;
	
	// temp
	private String temp_lab;
	private Blastpgp blastpgp;
	private PSIPREDRunner psipred;
	private PSFMandJSD psfmAndJsd;
	
	private SeaDB90 seadb90;
	private double[][] psfm;
	private double[][] orig_pssm;
	private double[][] pss;
	private double[][] psa;
	private double[] jsd;
	
	private static final int winsize = 17;
	private static final String svm_tr_param = "-c 2.5 -g 0.025 -b 1";
	private static final String svm_tst_param = "-b 1";
	private static final double w_pssm = 1.0;
	private static final double w_pss = 1.8;
	private static final double w_psa = 1.8;
	private static final double w_blosum = 2.0;
	private static final double ali_gap_penalty = -2;
	private static final double w_g_As = 0.4;
	private static final double w_l_As = 0.1;
	private static final double w_Ls = 0.1;
	private static final double w_JSD = 0.2;
	
	/**
	 * @param args
	 * @throws Exception 
	 */
	public static void main(String[] args) throws Exception {
		if (7 != args.length){
			System.out.println("Hi\ne.g., \n"
					+ "private String queryname;\n"
					+ "private String queryseq;\n"
					+ "private String queryligtypes;		// e.g., \" ATP ADP CA ... III \"  or null\n"
					+ "private double idcut = 0.3;			// sequence identity cutoff (default is 0.3)\n" 
					+ "private String tempfolder;\n"
					+ "private String savefolder;\n"
					+ "private Integer imbalance_param; //suggestion is 6\n");
			System.exit(-1);
		}
		String queryname = args[0];
		String queryseq = args[1];
		String queryligtypes = args[2];
		double idcut = Double.parseDouble(args[3]);
		String tempfolder = args[4];
		String savefolder = args[5];
		Integer imbalance_param = Integer.parseInt(args[6]);
		
		long start_time = new Date().getTime();
		try{
			ILBR sitesea = new ILBR(queryname, queryseq, queryligtypes, idcut, tempfolder, 
					savefolder, imbalance_param);
			sitesea.doit();
			
		}catch(Exception e){
			System.out.println("ERROR RUNNER!");
			_File.writeToFile("job_error", savefolder+"/status.txt", false);
			throw e;
		}
		
		long end_time = new Date().getTime();
		System.out.println("Totally using " + ((end_time - start_time)/1000.0/60) + "-m");
		System.out.println("Have a good day!");
	}
	
	public ILBR(String queryname,
			String queryseq,
			String queryligtypes,
			double idcut,
			String tempfolder,
			String savefolder,
			int imbalance_param)throws Exception{
		this.queryname = queryname;
		this.queryseq = queryseq.replaceAll(" ", "").replaceAll("\t", "").replaceAll("\n", "").replaceAll("\r", "");
		this.queryligtypes = queryligtypes;
		this.idcut = idcut;
		this.savefolder = savefolder;
		this.imbalance_param = imbalance_param;
		
		char[] lab = new char[this.queryseq.length()];
		for (int i = 0; i < lab.length; i++)
			lab[i] = '1';
		temp_lab = new String(lab);
		
		if (!new File(tempfolder).exists()){
			new File(tempfolder).mkdirs();
		}
		if (!new File(savefolder).exists()){
			new File(savefolder).mkdirs();
		}
		
		if (null == blastpgp){
			String save_orig_pssm = tempfolder+"/"+queryname+".opssm";
			String save_psitmp_chk = tempfolder+"/"+queryname+".psitmp.chk";
			String save_blast_out = tempfolder+"/"+queryname+".blast.out";
			blastpgp = new Blastpgp(queryname, queryseq, FixParam.BLASTPGP_B, FixParam.BLASTPGP_J, FixParam.BLSATPGP_H,
					save_orig_pssm, save_psitmp_chk, save_blast_out);
			int[][] o_pssm = blastpgp.getOrigPssm();
			orig_pssm = new double[o_pssm.length][o_pssm[0].length];
			for (int i = 0; i < o_pssm.length; i++)
				for (int j = 0; j < o_pssm[i].length; j++)
					orig_pssm[i][j] = (double)o_pssm[i][j];
		}
		
		if (null == psipred){
			psipred = new PSIPREDRunner(queryname, queryseq, blastpgp, tempfolder);
			pss = psipred.getSSProb();
		}
		
		if (null == psfmAndJsd){
			psfmAndJsd = new PSFMandJSD(queryname, queryseq, blastpgp, psipred, tempfolder);
			jsd = psfmAndJsd.getAllAAsJSD();
			psfm = psfmAndJsd.getPSFM();
		}
		
		String save_sann_psa = tempfolder+"/"+queryname+".sa";
		if (!new File(save_sann_psa).isFile()){
			if (queryseq.length() < 1280){
				new SANNRunner(queryname, queryseq, save_sann_psa);	
			}else{
				int num = 6;
				int step = queryseq.length() / num;
				int mod = queryseq.length() % num;
				
				FileWriter fw = new FileWriter(save_sann_psa);
				for (int f = 0; f < num; f++){
					System.out.println(f+" ");
					int start_tst_index;
					int end_tst_index;
					if (f < mod){
						start_tst_index = f*step + f;
						end_tst_index = ((f+1)*step>queryseq.length() ? queryseq.length() : (f+1)*step) + (f+1);
					}else{
						start_tst_index = f*step + mod;
						end_tst_index = ((f+1)*step>queryseq.length() ? queryseq.length() : (f+1)*step) + mod;
					}
					
					new SANNRunner(queryname, queryseq.substring(start_tst_index, end_tst_index), save_sann_psa+"_"+f);
					
					String fth_sa = _File.load2Str(save_sann_psa+"_"+f);
					if (0==f){
						fw.write(fth_sa.trim()+"\n");
					}else{
						String[] fth_sa_lc = fth_sa.trim().split("\n");
						for (int i = 2; i < fth_sa_lc.length; i++){
							fw.write(fth_sa_lc[i]+"\n");
						}
					}
					new File(save_sann_psa+"_"+f).delete();
				}
				fw.close();
			}
		}
		psa = SANNRunner.getPSAProbs(save_sann_psa);
		
		// Release the null object memory
		System.gc();
		Thread.sleep(2000);
	}
	
	private void doit() throws Exception{
		String templprot_info_path = savefolder + "/" + queryname + ".conditional1_templ_info"; 	// protname : ATP#23 24 26 102$ADP#12 24
		if (!new File(templprot_info_path+".final").isFile()){
			if (null == seadb90)
				seadb90 = new SeaDB90(queryname, queryseq, idcut, queryligtypes, psfm, jsd, orig_pssm, pss, psa,
						w_pssm,  w_pss,  w_psa,  w_blosum,  ali_gap_penalty,
						w_g_As,  w_l_As,  w_Ls,  w_JSD);
			FileWriter fw = new FileWriter(templprot_info_path+".final");
			
			HashMap<String, StringBuffer> pssm_search_info = seadb90.getSeaRes();
			Object[] pssm_ids = pssm_search_info.keySet().toArray();
			for (int i = 0; i < pssm_ids.length; i++){
				String protname = (String)pssm_ids[i];
				StringBuffer bsites_info = pssm_search_info.get(protname);
				fw.write(protname+"\t" + bsites_info.toString()+"\n");
			}
			fw.close();
			double[] voteProb = seadb90.getVoteProb();
			_File.writeToFile(voteProb, templprot_info_path+".vote_prob", false);
		}
		
		// Release the null object memory
		System.gc();
		Thread.sleep(2000);
		
		prepareProtSpecificTrSamsFile(templprot_info_path+".final", imbalance_param, 
				savefolder + "/" + queryname + ".conditional1_templ_info.libsvm_sams." + imbalance_param);
		// train svm model
		LIBSVMRunner.train(svm_tr_param, savefolder + "/" + queryname + ".conditional1_templ_info.libsvm_sams." + imbalance_param, 
				savefolder + "/" + queryname + ".conditional1_templ_info.libsvm_mod."+imbalance_param);
		
		// Release the null object memory
		System.gc();
		Thread.sleep(2000);
		
		prepareQueryProtTstSamsFile(savefolder + "/" + queryname + ".tst.libsvm_sams."+imbalance_param);
		// predict query
		LIBSVMRunner.libsvm_predict(temp_lab, svm_tst_param,
				savefolder + "/" + queryname + ".tst.libsvm_sams."+imbalance_param, 
				savefolder + "/" + queryname + ".conditional1_templ_info.libsvm_mod."+imbalance_param,
				savefolder + "/" + queryname + ".tst.specific_libsvm_res." + imbalance_param);
		
		double[][] junres = _File.loadMatrix(savefolder + "/" + queryname + ".tst.specific_libsvm_res." + imbalance_param);
		FileWriter fw = new FileWriter(savefolder + "/" + queryname + ".final.csv");
		fw.write(	_Str.replenishHeadWithSpace("Ind.", 4) + ", " 
				+ 	_Str.replenishHeadWithSpace("AA.", 3) + ", "
				+ 	_Str.replenishHeadWithSpace("Prob.", 6) + "\n");
		for (int i = 0; i < this.queryseq.length(); i++) {
			fw.write(	_Str.replenishHeadWithSpace(""+i, 4) + ", " 
					+ 	_Str.replenishHeadWithSpace(this.queryseq.substring(i, i+1), 3) + ", "
					+ 	_Str.replenishHeadWithSpace(_NumFormat.formatDouble(junres[i][1], "#0.000"), 6) + "\n");
		}
		fw.close();
		
		//=======================================================================================
		// remove useless files
		//=======================================================================================
		if (new File(savefolder + "/" + queryname + ".conditional1_templ_info.libsvm_sams."+imbalance_param).isFile()){
			new File(savefolder + "/" + queryname + ".conditional1_templ_info.libsvm_sams."+imbalance_param).delete();
		}
		if (new File(savefolder + "/" + queryname + ".conditional1_templ_info.libsvm_mod."+imbalance_param).isFile()){
			new File(savefolder + "/" + queryname + ".conditional1_templ_info.libsvm_mod."+imbalance_param).delete();
		}
		if (new File(savefolder + "/" + queryname + ".tst.libsvm_sams."+imbalance_param).isFile()){
			new File(savefolder + "/" + queryname + ".tst.libsvm_sams."+imbalance_param).delete();
		}
	}
	
	private void prepareQueryProtTstSamsFile(String savepath)throws Exception{
		double[][] win_pssm = SeqFea.winPSSMFea4AA(sigmoidPSSM(orig_pssm), winsize);
		double[][] win_pss = SeqFea.winPSSFea4AA(pss, winsize);
		double[][] win_psa = SeqFea.winSANNa3Fea4AA(psa, winsize);
		
		// using the bsites information to generate the training samples
		
		double[][] labmtx = new double[win_pssm.length][1];
		for (int i = 0; i < win_pssm.length; i++){
			labmtx[i][0] = 1.0;
		}
		
		double[][] sams = _Matrix.matrixCatPerRow(win_pssm, win_pss, win_psa, labmtx);
		SampleSaved.saveUseLIBSVMFormatBySpace(sams, savepath);
	}
	
	private void prepareProtSpecificTrSamsFile(String train_prot_profile, int imRatio, String savepath)throws Exception{
		String siteseaDBFolder = ConfigUtil.getConfig("SITESEA_DB_FOLDER");
		if (null == siteseaDBFolder){
			System.out.println("Please check the config file items : SITESEA_DB_FOLDER");
			_Log.dayRunLog("Please check the config file items : SITESEA_DB_FOLDER", new Date());
			System.exit(-1);
		}
		
		Vector<double[]> tr_sams = new Vector<double[]>();
		
		BufferedReader br = new BufferedReader(new FileReader(train_prot_profile));
		String l = br.readLine();
		while (null != l){
			String[] lc = l.split("	");
			String protname = lc[0];
			String protinfo = lc[1];
			
			// load database protein pssm, pss, psa information
			String pssm_path = siteseaDBFolder + "/PSSM/"+protname+".pssm";
			String pss_path = siteseaDBFolder + "/PSS/"+protname+".pss";
			String psa_path = siteseaDBFolder + "/PSA/"+protname+".psa";
			if (!new File(pssm_path).isFile() || !new File(pss_path).isFile() || !new File(psa_path).isFile()){
				l = br.readLine();
				continue;
			}
			double[][] psa_prob = null;
			try{
				psa_prob = _File.loadSANNa3(psa_path);
			}catch(Exception e){
				System.out.println("Hey! !!!");
				e.printStackTrace();
				new File(psa_path).delete();
				l = br.readLine();
				continue;
			}
			double[][] orig_pssm = _File.loadMatrix(pssm_path);
			double[][] pss_prob = _File.loadPsipredPSS(pss_path);
			
			double[][] win_pssm = SeqFea.winPSSMFea4AA(sigmoidPSSM(orig_pssm), winsize);
			double[][] win_pss = SeqFea.winPSSFea4AA(pss_prob, winsize);
			double[][] win_psa = SeqFea.winSANNa3Fea4AA(psa_prob, winsize);
			
			// using the bsites information to generate the training samples
			
			double[][] labmtx = new double[win_pssm.length][1];
			for (int i = 0; i < win_pssm.length; i++){
				labmtx[i][0] = 2.0;
			}
			
			String[] pocinfo = protinfo.split("CSBIONJUST");
			for (int i = 0; i < pocinfo.length; i++){
				String i_pocinfo = pocinfo[i];
				String[] poc_info_items = i_pocinfo.split("#");
//				String ligtype = poc_info_items[0];
//				String confsco = poc_info_items[1];
				String[] bsites = poc_info_items[2].split(" ");
				
				for (int j = 0; j < bsites.length; j++){
					int ind = Integer.parseInt(bsites[j]);
					labmtx[ind][0] = 1.0;
				}
			}
			
			double[][] sams = _Matrix.matrixCatPerRow(win_pssm, win_pss, win_psa, labmtx);
			System.out.println(protname + "\t" + sams.length);
			
			tr_sams = _Matrix.matrixCat(tr_sams, sams);
			l = br.readLine();
		}
		br.close();
		
		Vector<double[]> final_tr_sams = _Sampling.RUOS(tr_sams, imRatio, imRatio);
		
		System.out.println("sample number is " + final_tr_sams.size());
		
		SampleSaved.saveUseLIBSVMFormatBySpace(_Matrix.exchangeVDArrToD2Arr(final_tr_sams), savepath);
	}
	
	private double[][] sigmoidPSSM(double[][] orig_pssm){
		double[][] ans = new double[orig_pssm.length][20];
		for (int i = 0; i < orig_pssm.length; i++){
			for (int j = 0; j < 20; j++){
				ans[i][j] = 1.0 / (1.0 + Math.exp(-orig_pssm[i][j]));
			}
		}
		
		return ans;
	}
	
}
