package _implement;

import java.io.BufferedReader;
import java.io.File;
import java.io.FileReader;
import java.util.Date;
import java.util.Vector;

import _runner.Blastpgp;
import _runner.PSIPREDRunner;
import _util.ConfigUtil;
import _util.StreamGobbler;
import _util._File;
import _util._Log;

public class PSFMandJSD {
	private String protname;
	private String protseq;
	private Blastpgp blastpgp;
	private PSIPREDRunner psipred;
	private String tempfolder;
	
	private String save_blast_fasta;
	private String save_query_profile; // save query PSFM profile
	private String save_jsd_score;
	
	// temp
	private double[] jsd_score;
	private double[][] psfm;
	
	// final
	private static final int BLASTPGP_B = 1000;
	private static final int BLASTPGP_J = 3;
	private static final double BLSATPGP_H = 0.001;
	/**
	 * @param protname
	 * @param protseq
	 * @param blastpgp
	 * @param psipred
	 * @param save_blast_fasta
	 * @param save_query_profile
	 * @param save_jsd_score
	 */
	public PSFMandJSD(String protname, String protseq, Blastpgp blastpgp, PSIPREDRunner psipred, String tempfolder) {
		this.protname = protname;
		this.protseq = protseq;
		this.blastpgp = blastpgp;
		this.psipred = psipred;
		this.tempfolder = tempfolder;
		
		if (!new File(tempfolder).exists())
			new File(tempfolder).mkdirs();
		
		if (null == this.blastpgp){
			String save_orig_pssm = this.tempfolder + "/" + protname + ".opssm";
			String save_psitmp_chk = this.tempfolder + "/" + protname + ".psitmp.chk";
			String save_blast_out = this.tempfolder + "/" + protname + ".blast.out";
			
			this.blastpgp = new Blastpgp(protname, protseq, BLASTPGP_B, BLASTPGP_J, BLSATPGP_H, save_orig_pssm, save_psitmp_chk,
					save_blast_out);
		}
		
		if (null == this.psipred){
			this.psipred = new PSIPREDRunner(protname, protseq, blastpgp, tempfolder);
		}
		
		save_blast_fasta = this.tempfolder + "/" + protname + ".blast_fasta";
		save_query_profile = this.tempfolder + "/" + protname + ".query_profile";
		save_jsd_score = this.tempfolder + "/" + protname + ".jsd_score";
		
		if (!new File(save_blast_fasta).isFile() || !new File(save_query_profile).isFile())
			this.prepareBlastFaAndQueryProfile();
		if (!new File(save_jsd_score).isFile())
			this.JSDrunner();
	}
	
	public PSFMandJSD(String protname, String protseq, String tempfolder) {
		this.protname = protname;
		this.protseq = protseq;
		this.tempfolder = tempfolder;
		
		if (!new File(tempfolder).exists())
			new File(tempfolder).mkdirs();
		
		if (null == this.blastpgp){
			String save_orig_pssm = this.tempfolder + "/" + protname + ".opssm";
			String save_psitmp_chk = this.tempfolder + "/" + protname + ".psitmp.chk";
			String save_blast_out = this.tempfolder + "/" + protname + ".blast.out";
			
			this.blastpgp = new Blastpgp(protname, protseq, BLASTPGP_B, BLASTPGP_J, BLSATPGP_H, save_orig_pssm, save_psitmp_chk,
					save_blast_out);
		}
		
		if (null == this.psipred){
			this.psipred = new PSIPREDRunner(protname, protseq, blastpgp, tempfolder);
		}
		
		save_blast_fasta = this.tempfolder + "/" + protname + ".blast_fasta";
		save_query_profile = this.tempfolder + "/" + protname + ".query_profile";
		save_jsd_score = this.tempfolder + "/" + protname + ".jsd_score";
		
		if (!new File(save_blast_fasta).isFile() || !new File(save_query_profile).isFile())
			this.prepareBlastFaAndQueryProfile();
		if (!new File(save_jsd_score).isFile())
			this.JSDrunner();
	}
	
	/**
	 * @return the protname
	 */
	public String getProtname() {
		return protname;
	}

	/**
	 * @return the protseq
	 */
	public String getProtseq() {
		return protseq;
	}

	/**
	 * @return the blastpgp
	 */
	public Blastpgp getBlastpgp() {
		return blastpgp;
	}

	/**
	 * @return the psipred
	 */
	public PSIPREDRunner getPsipred() {
		return psipred;
	}

	/**
	 * @return the save_blast_fasta
	 */
	public String getsave_blast_fasta() {
		return save_blast_fasta;
	}

	/**
	 * @return the save_query_profile
	 */
	public String getsave_query_profile() {
		return save_query_profile;
	}

	/**
	 * @return the save_jsd_score
	 */
	public String getSave_jsd_score() {
		return save_jsd_score;
	}
	
	public double[] getAllAAsJSD(){
		if (null == this.jsd_score){
			try{
				Vector<Double> _jsd_score_vec = new Vector<Double>();
				BufferedReader br = new BufferedReader(new FileReader(this.save_jsd_score));
				String line = br.readLine();
				while (null != line){
					String[] lc = line.replaceAll("\t", " ").split(" +");
					if (lc.length <= 2){
						System.out.println("EEEEEEEEEEEEEEEERORR!");
					}
					
					_jsd_score_vec.add(Double.parseDouble(lc[2]));
					line = br.readLine();
				}
				br.close();
				
				this.jsd_score = new double[_jsd_score_vec.size()];
				for (int i = 0; i < _jsd_score_vec.size(); i++)
					this.jsd_score[i] = _jsd_score_vec.get(i);
			}catch(Exception e){
				e.printStackTrace();
			}
		}
		
		return this.jsd_score;
	}
	
	public double getIthAAJSD(int index){
		if (null == this.jsd_score){
			try{
				Vector<Double> _jsd_score_vec = new Vector<Double>();
				BufferedReader br = new BufferedReader(new FileReader(this.save_jsd_score));
				String line = br.readLine();
				while (null != line){
					String[] lc = line.replaceAll("\t", " ").split(" +");
					if (lc.length != 4){
						System.out.println("EEEEEEEEEEEEEEEERORR!");
					}
					
					_jsd_score_vec.add(Double.parseDouble(lc[2]));
					line = br.readLine();
				}
				br.close();
				
				this.jsd_score = new double[_jsd_score_vec.size()];
				for (int i = 0; i < _jsd_score_vec.size(); i++)
					this.jsd_score[i] = _jsd_score_vec.get(i);
			}catch(Exception e){
				e.printStackTrace();
			}
		}
		
		return this.jsd_score[index];
	}
	
	public double[][] getPSFM(){
		if (null == this.psfm){
			try{
				Vector<double[]> _psfm = new Vector<double[]>();
				BufferedReader br = new BufferedReader(new FileReader(this.save_query_profile));
				String line = br.readLine();
				while (null != line){
					String[] lc = line.replaceAll("\t", " ").split(" +");
					if (lc.length != 22){
						System.out.println("PSFMandJSD:222 says: EEEEEEEEEEEEEEEERORR!");
					}
					double[] arr = new double[20];
					for (int i = 0; i < 20; i++){
						arr[i] = Double.parseDouble(lc[i+2]);
					}
					_psfm.add(arr);
					line = br.readLine();
				}
				br.close();
				
				this.psfm = new double[_psfm.size()][20];
				for (int i = 0; i < _psfm.size(); i++)
					this.psfm[i] = _psfm.get(i);
			}catch(Exception e){
				e.printStackTrace();
			}
		}
		
		return psfm;
	}
	
	private void prepareBlastFaAndQueryProfile(){
		String BLASTPGP_OUTPUT_PARSER_DIR = ConfigUtil.getConfig("BLASTPGP_OUTPUT_PARSER_DIR");
		if (null == BLASTPGP_OUTPUT_PARSER_DIR) {
			System.out.println("Please ensure the Config params: BLASTPGP_OUTPUT_PARSER_DIR");
			System.exit(-1);
		}
		
		long suffix = new Date().getTime();
		String protfasta_path = "./"+protname+".fa_"+suffix;
		_File.writeToFile(">"+protname+"\n"+protseq, protfasta_path, false);
		String cmd =  BLASTPGP_OUTPUT_PARSER_DIR+"/prepareQueryPSFM.pl "
				+ "-protfasta_path "+protfasta_path + " "
				+ "-sequence "+protseq + " "
				+ "-blast_out_path " + blastpgp.getBlast_outPath() + " "
				+ "-psipredSS_path " + psipred.getSaveSSPath() + " "
				+ "-parse_blast_pl_path "+BLASTPGP_OUTPUT_PARSER_DIR+"/parse_blast.pl "
				+ "-blast_fasta " + save_blast_fasta + " "
				+ "-saveQueyPSFM "+save_query_profile;
		
		System.out.println(cmd);
		_Log.dayRunLog(cmd, new Date());
		
		try{
			Process process;
			process = Runtime.getRuntime().exec(cmd);
			StreamGobbler errorGobbler = new StreamGobbler(process.getErrorStream(), "Error");
			errorGobbler.start();
			StreamGobbler outputGobbler = new StreamGobbler(process.getInputStream(), "Output");
			outputGobbler.start();
			
			process.waitFor();
			process.destroy();
			
		}catch(Exception e){
			e.printStackTrace();
			_Log.dayRunLog("Cannot correctly run \""+cmd+"\"", new Date());
			_Log.dayRunLog(e.getMessage(), new Date());
		}
		
		new File(protfasta_path).delete();
	}

	private void JSDrunner(){
		if (!new File(save_blast_fasta).isFile())
			prepareBlastFaAndQueryProfile();
		
		String BLASTPGP_OUTPUT_PARSER_DIR = ConfigUtil.getConfig("BLASTPGP_OUTPUT_PARSER_DIR");
		if (null == BLASTPGP_OUTPUT_PARSER_DIR) {
			System.out.println("Please ensure the Config params: BLASTPGP_OUTPUT_PARSER_DIR");
			System.exit(-1);
		}
		
		String cmd = BLASTPGP_OUTPUT_PARSER_DIR+"/JSDcalculator.pl "
				+ "-query_sequence "+protseq+" "
				+ "-blast_fasta_path "+save_blast_fasta+" "
				+ "-save_jsd_score_path "+save_jsd_score;
		
		System.out.println(cmd);
		
		_Log.dayRunLog(cmd, new Date());
		
		try{
			Process process;
			process = Runtime.getRuntime().exec(cmd);
			StreamGobbler errorGobbler = new StreamGobbler(process.getErrorStream(), "Error");
			errorGobbler.start();
			StreamGobbler outputGobbler = new StreamGobbler(process.getInputStream(), "Output");
			outputGobbler.start();
			
			process.waitFor();
			process.destroy();
			
		}catch(Exception e){
			e.printStackTrace();
			_Log.dayRunLog("Cannot correctly run \""+cmd+"\"", new Date());
			_Log.dayRunLog(e.getMessage(), new Date());
		}
	}
	
}
